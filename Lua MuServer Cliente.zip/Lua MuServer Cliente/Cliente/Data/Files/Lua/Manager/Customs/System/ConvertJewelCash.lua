-- Convert-JewelCash: Ctrl + botao direito no item do inventario.
-- O servidor valida o item e a conversao.
ConvertJewelCashClient = {}
local packetId = 220 -- igual ao Packet na configuracao do servidor

function ConvertJewelCashClient.RightClick()
    if CheckRepeatKey(Keys.ControlKey) == 0 then return end
    local slot = GetInventoryMouseItemSlot()
    if type(slot) ~= "number" or slot < 12 or slot > 203 then return end
    local name = UserGetName()
    if not name or name == "" then return end
    local packet = "JEWELCASH-" .. name
    CreatePacket(packet, packetId)
    SetBytePacket(packet, slot)
    SendPacket(packet)
    ClearPacket(packet)
end

InterfaceController.InterfaceClickRightEvent(ConvertJewelCashClient.RightClick)
return ConvertJewelCashClient
