-- Ctrl + botao direito sobre o item no inventario. O servidor valida a requisicao.
local packetId = 219 -- igual ao NPCMoveCustomConfig do servidor
local function rightClick()
    if CheckRepeatKey(Keys.ControlKey) == 0 then return end
    local slot = GetInventoryMouseItemSlot()
    if slot < 12 or slot > 203 then return end
    local name = UserGetName()
    if not name or name == "" then return end
    local packet = "NPCMOVE-" .. name
    CreatePacket(packet, packetId)
    SetBytePacket(packet, slot)
    SendPacket(packet)
    ClearPacket(packet)
end
InterfaceController.InterfaceClickRightEvent(rightClick)
return rightClick
