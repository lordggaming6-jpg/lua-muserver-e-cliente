-- Lua 5.1. Interface do bau multiplo: setas e contador "N / TOTAL".
-- Este arquivo e carregado pelo cliente (ReaderIMG.lua chama Warehouse.*), por isso
-- TODO o desenho fica aqui. Nao le nem escreve memoria nativa.
-- As transacoes de Zen continuam nos botoes originais do cliente.
Warehouse = Warehouse or {}
local UI = Warehouse
local packetNumber = 0x66
local maximum, selected, ready = 0, 0, false
local wasOpen, popup, input = false, false, ""
local lastRequest, pending = nil, false
local registered = false

-- Layout desta skin, em coordenadas virtuais do cliente.
-- Posicoes aprovadas no print: navegacao em Y=357, a esquerda do Zen.
-- Os deslocamentos abaixo ja foram fixados conforme o ajuste do usuario.
-- O servidor usa IDs a partir de zero; a interface mostra 1 ate maximum + 1.
local CONFIG = {
    navX = 30, navY = 336,
    arrowW = 25, counterW = 78, navH = 16,
    -- Areas nativas de deposito, retirada e trava, ja usadas por esta skin.
    btnX = 27, btnY = 388, btnW = 24, btnH = 24, btnStep = 29,
    calibration = true, -- Alt + 1..6 seleciona; Alt + setas move um por vez.
    -- Copie aqui os deslocamentos exibidos durante o ajuste para salva-los.
    offsets = {
        previous = {x = -10, y = 21},
        next = {x = -20, y = 21},
        counter = {x = -14, y = 21},
        deposit = {x = 0, y = 0},
        withdraw = {x = 13, y = 0},
        lock = {x = 22, y = 0},
    },
}

-- Texturas originais do Custom.zip: JPEG 54x162 com tres quadros 54x54.
-- O cliente usa nomes .jpg no LoadImage para os arquivos .ozj de Data/Custom.
local images = {
    previous = {file = "btn_arrowleft", id = 7620100},
    next = {file = "btn_arrowright", id = 7620101},
    deposit = {file = "btn_deposit_v2", id = 7620102},
    withdraw = {file = "btn_withdraw_v2", id = 7620103},
    lock = {file = "btn_lock_v2", id = 7620104},
}
local imagesLoaded = false

local controls = {
    {key = "previous", label = "Seta esquerda"},
    {key = "next", label = "Seta direita"},
    {key = "counter", label = "Contador"},
    {key = "deposit", label = "Depositar Zen"},
    {key = "withdraw", label = "Retirar Zen"},
    {key = "lock", label = "Trancar/destrancar"},
}
local adjustSelected, moveX, moveY, moveTicks = 1, 0, 0, 0

local function down(key)
    return CheckRepeatKey(key) == 1
end

local function adjusting()
    return CONFIG.calibration and not popup
        and (UIChatWindow == nil or CheckWindowOpen(UIChatWindow) ~= 1)
        and (down(18) or down(164) or down(165))
end

local function offsetRect(name, x, y, w, h)
    local offset = CONFIG.offsets[name]
    return {x = x + offset.x, y = y + offset.y, w = w, h = h}
end

local function integer(n)
    return type(n) == "number" and n == n and n >= 0
        and n <= 2147483647 and n == math.floor(n)
end

local function warehouseX()
    local width = type(WindowGetWidth) == "function" and WindowGetWidth() or 640
    local expanded = UIExpandInventory ~= nil and CheckWindowOpen(UIExpandInventory) == 1
    return width - 380 - (expanded and 190 or 0)
end

local function btnOrigin()
    return warehouseX() + CONFIG.btnX, CONFIG.btnY
end

-- Desenho e cliques usam os mesmos retangulos, inclusive em tela larga.
local function navRects()
    local x, y = warehouseX() + CONFIG.navX, CONFIG.navY
    local aw, cw, h = CONFIG.arrowW, CONFIG.counterW, CONFIG.navH
    return offsetRect("previous", x, y, aw, h),
           offsetRect("counter", x + aw, y, cw, h),
           offsetRect("next", x + aw + cw, y, aw, h)
end

local function hover(x, y, w, h)
    local mx, my = MousePosX(), MousePosY()
    return mx >= x and mx < x + w and my >= y and my < y + h
end

local function hoverRect(r) return hover(r.x, r.y, r.w, r.h) end

-- Mesmo ciclo de desenho usado em ShopButton.DrawScriptButton. A cor e
-- aplicada DEPOIS de SetBlend a cada barra: a API restaura o estado entre elas.
local function paint(x, y, w, h, r, g, b)
    EnableAlphaTest()
    SetBlend()
    glColor4f(r, g, b, 1)
    DrawBar(x, y, w, h)
    EndDrawBar()
    GLSwitchBlend()
    GLSwitch()
    glColor3f(1, 1, 1)
    DisableAlphaBlend()
end

local function box(x, y, w, h, over, shade)
    shade = shade or 1
    local function layer(dx, dy, width, height, r, g, b)
        paint(x + dx, y + dy, width, height, r * shade, g * shade, b * shade)
    end
    -- Mesma moldura, fundo e relevo bronze do Menu/Shop.
    layer(0, 0, w, h, .34, .29, .20)
    layer(1, 1, w - 2, h - 2, .065, .07, .07)
    layer(2, 2, w - 4, 1, .64, .53, .33)
    layer(2, h - 3, w - 4, 1, .17, .15, .10)
    if over then layer(2, 2, w - 4, 1, .90, .76, .47) end
end

local function gold(x, y, w, h, shade)
    paint(x, y, w, h, .90 * shade, .76 * shade, .47 * shade)
end

local function text(x, y, value, width, enabled)
    EnableAlphaTest()
    SetFontType(0)
    SetTextBg(0, 0, 0, 0)
    if enabled == false then SetTextColor(110, 105, 90, 255)
    else SetTextColor(230, 194, 120, 255) end
    RenderText2(x, y, value, width, 3)
end

local function button(x, y, w, h, label, enabled)
    box(x, y, w, h, enabled ~= false and hover(x, y, w, h))
    text(x, y + math.floor((h - 10) / 2), label, w, enabled)
end

-- Cada atlas tem normal/hover/pressionado, nesta ordem. Como nas demais
-- interfaces do cliente, UVs consideram a textura OpenGL 64x256. Recorta uma
-- borda de um pixel para nao misturar quadros durante a filtragem.
local function imageButton(name, r, enabled)
    if not imagesLoaded then UI.LoadImages() end
    local over = enabled ~= false and hoverRect(r)
    local pressed = over and not adjusting() and type(CheckPressedKey) == "function"
        and CheckPressedKey(1) == 1
    local frame = pressed and 2 or (over and 1 or 0)
    local shade = enabled == false and .4 or 1
    EnableAlphaTest()
    glColor4f(shade, shade, shade, 1)
    RenderImage2(images[name].id, r.x, r.y, r.w, r.h,
        1 / 64, (frame * 54 + 1) / 256, 52 / 64, 52 / 256, 1, 1, 1)
    glColor4f(1, 1, 1, 1)
    DisableAlphaBlend()
end

local function controlRect(index)
    local left, mid, right = navRects()
    if index == 1 then return left end
    if index == 2 then return right end
    if index == 3 then return mid end
    local bx, by = btnOrigin()
    return offsetRect(controls[index].key, bx + (index - 4) * CONFIG.btnStep,
        by, CONFIG.btnW, CONFIG.btnH)
end

-- Coordenadas de deslocamento, relativas ao bau, independentes da resolucao.
-- Exibidas somente enquanto Alt esta pressionado, durante a calibracao.
local function drawAdjustment()
    if not adjusting() then return end
    local r = controlRect(adjustSelected)
    gold(r.x - 1, r.y - 1, r.w + 2, 1, 1)
    gold(r.x - 1, r.y + r.h, r.w + 2, 1, 1)
    gold(r.x - 1, r.y, 1, r.h, 1)
    gold(r.x + r.w, r.y, 1, r.h, 1)
    box(8, 240, 260, 118, false)
    text(10, 244, "AJUSTE: " .. controls[adjustSelected].label, 256)
    text(10, 258, "Alt+1..6 seleciona | Alt+setas move", 256)
    for index, control in ipairs(controls) do
        local offset = CONFIG.offsets[control.key]
        local value = string.format("%d %s = {x = %d, y = %d},",
            index, control.key, offset.x, offset.y)
        text(10, 272 + (index - 1) * 12, value, 256, index == adjustSelected)
    end
end

-- Apenas o desenho: as operacoes nativas de Zen e senha continuam no cliente.
local function nativeButtons()
    for index = 4, 6 do
        imageButton(controls[index].key, controlRect(index), true)
    end
end

function UI.Close()
    popup, input = false, ""
end

-- Janela do bau aberta?
local function visible()
    if UIWarehouse == nil then return false end
    local ok, r = pcall(CheckWindowOpen, UIWarehouse)
    if not ok then return false end
    if r ~= 1 then
        wasOpen = false
        UI.Close()
        return false
    end
    return true
end

local function requestInfo()
    local now = os.time()
    if lastRequest and now >= lastRequest and now - lastRequest < 3 then return end
    lastRequest = now
    local name = string.format("WHouse_Info_%s", UserGetName())
    CreatePacket(name, packetNumber)
    SendPacket(name)
    ClearPacket(name)
end

local function drawWindow()
    if not wasOpen then
        wasOpen, pending, ready = true, false, false
        lastRequest = nil
    end
    if not ready or pending then requestInfo() end
    local bx, by = btnOrigin()
    local left, mid, right = navRects()

    -- Linha abaixo dos itens: [<] N / TOTAL [>].
    button(mid.x, mid.y, mid.w, mid.h,
        ready and string.format("%d / %d", selected + 1, maximum + 1) or "Aguardando...", ready)
    imageButton("previous", left, ready and selected > 0 and not pending)
    imageButton("next", right, ready and selected < maximum and not pending)

    nativeButtons()

    if popup then
        local px, py = bx + 10, by - 270
        box(px, py, 140, 77, false)
        text(px, py + 5, "Escolha o bau (1 a " .. (maximum + 1) .. ")", 140)
        box(px + 10, py + 20, 120, 18, true)
        text(px + 10, py + 24, input .. "|", 120)
        button(px + 10, py + 47, 57, 20, "Alterar", true)
        button(px + 73, py + 47, 57, 20, "Fechar", true)
    end
end

function UI.SendPacket(number)
    if adjusting() or not ready or pending or not integer(number) or number > maximum
        or number == selected or not visible() then return false end
    UI.Close()
    pending = true
    CloseWindow(UIWarehouse)   -- o servidor exige o bau fechado antes de trocar
    if UIExpandWarehouse ~= nil then CloseWindow(UIExpandWarehouse) end
    local name = string.format("WHouse_Change_%s", UserGetName())
    CreatePacket(name, packetNumber)
    SetDwordPacket(name, number)
    SendPacket(name)
    ClearPacket(name)
    return true
end

function UI.InterfaceClickEvent()
    if not visible() then return end
    if adjusting() then return true end
    local left, mid, right = navRects()
    local bx, by = btnOrigin()
    if popup then
        local px, py = bx + 10, by - 270
        if hover(px + 10, py + 47, 57, 20) then
            local number = tonumber(input)
            if number == selected + 1 then UI.Close()
            elseif number then UI.SendPacket(number - 1) end
        elseif hover(px + 73, py + 47, 57, 20) then UI.Close() end
        return true
    end
    if not ready or pending then return end
    if hoverRect(left) then return UI.SendPacket(selected - 1) end
    if hoverRect(right) then return UI.SendPacket(selected + 1) end
    if hoverRect(mid) then
        popup, input = true, tostring(selected + 1)
        return true
    end
end

function UI.UpdateMouse()
    if not visible() then return end
    if adjusting() then DisableClickClient(); return end
    local left, mid, right = navRects()
    if popup or hoverRect(left) or hoverRect(mid) or hoverRect(right) then DisableClickClient() end
end

function UI.KeyListener(key)
    if not visible() then return end
    if adjusting() then return true end
    if not popup then return end
    if key == 27 then UI.Close(); return true end
    if key == 13 then
        local number = tonumber(input)
        if number == selected + 1 then UI.Close()
        elseif number then UI.SendPacket(number - 1) end
        return true
    end
    local digit
    if key >= 48 and key <= 57 then digit = key - 48
    elseif key >= 96 and key <= 105 then digit = key - 96 end
    if digit and #input < 10 then input = input .. digit; return true end
end

local function keyStep()
    if not visible() then
        moveX, moveY, moveTicks = 0, 0, 0
        return
    end
    if popup then
        moveX, moveY, moveTicks = 0, 0, 0
        DisableClickClient()
        if down(8) then input = input:sub(1, -2) end
        return
    end
    if not adjusting() then
        moveX, moveY, moveTicks = 0, 0, 0
        return
    end
    DisableClickClient()
    for index = 1, #controls do
        if down(48 + index) or down(96 + index) then
            if adjustSelected ~= index then moveX, moveY, moveTicks = 0, 0, 0 end
            adjustSelected = index
            break
        end
    end
    local dx = (down(39) and 1 or 0) - (down(37) and 1 or 0)
    local dy = (down(40) and 1 or 0) - (down(38) and 1 or 0)
    if dx == 0 and dy == 0 then
        moveX, moveY, moveTicks = 0, 0, 0
        return
    end
    if dx ~= moveX or dy ~= moveY then moveTicks = 0 end
    moveX, moveY, moveTicks = dx, dy, moveTicks + 1
    -- Um passo ao apertar; ao segurar, repete apos 12 atualizacoes, a cada 3.
    if moveTicks ~= 1 and (moveTicks < 12 or moveTicks % 3 ~= 0) then return end
    local offset = CONFIG.offsets[controls[adjustSelected].key]
    offset.x, offset.y = offset.x + dx, offset.y + dy
end

function UI.ClientProtocol(packet, name)
    if packet ~= packetNumber or name ~= string.format("WHouse_%s", UserGetName()) then
        return false
    end
    local limit, current = GetDwordPacket(name, -1), GetDwordPacket(name, -1)
    if integer(limit) and integer(current) then
        maximum, selected, ready, pending = limit, current, true, false
    end
    ClearPacket(name)
    return true
end

-- ReaderIMG chama estes pontos de entrada. Nao registrar outro MainProc.
local function draw()
    UI.Register()
    if not visible() then return end
    EnableAlphaTest()
    drawWindow()
    drawAdjustment()
    GLSwitch()
    glColor4f(1, 1, 1, 1)
    DisableAlphaBlend()
end

-- Registra cliques, mouse, teclas e o pacote do servidor (uma unica vez).
function UI.Register()
    if registered or type(InterfaceController) ~= "table" then return end
    registered = true
    InterfaceController.ClientProtocol(UI.ClientProtocol)
    InterfaceController.InterfaceClickEvent(UI.InterfaceClickEvent)
    InterfaceController.UpdateMouse(UI.UpdateMouse)
    InterfaceController.MainProcWorldKey(UI.KeyListener)
    InterfaceController.UpdateKey(keyStep)
    InterfaceController.LoadImages(UI.LoadImages)
end

UI.MakeInterface = draw
UI.MakeIcons = draw
function UI.Init() UI.Register() end
function UI.LoadImages()
    if imagesLoaded then return end
    for _, name in ipairs({"previous", "next", "deposit", "withdraw", "lock"}) do
        local entry = images[name]
        LoadImage("Custom\\Interface\\" .. entry.file .. ".jpg", entry.id)
    end
    imagesLoaded = true
end
-- Se o cliente chamar Warehouse.UpdateKey diretamente e o controller nao existir:
function UI.UpdateKey() if not registered then keyStep() end end

UI.Register()
return UI
