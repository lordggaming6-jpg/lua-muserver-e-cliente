-- QUEST V2 - configure apenas a apresentacao aqui. Regras/recompensas vem do servidor.
QuestSystemNpc = {}
local Q=QuestSystemNpc
Q.Config={
    Enabled=true,
    Shortcut=84, -- T: abre/fecha a janela da quest
    Window={X=120,Y=65,W=400,H=310},
    RefreshSeconds=2,
    ExtraWindowChecks={}, -- funcoes adicionais que retornam true quando outra janela abre
}
local C=Q.Config
local S={Open=false,Sequence=0,List={},Rows={},Rewards={},Selected=0,Run=0,State=0,Page=0,RewardPage=0,ListPage=0}
local controls={}
local incoming
local shortcutDown=false
local gold,white,muted,green={232,205,150},{218,211,191},{150,143,124},{137,211,104}
local native={1,2,3,4,6,7,8,9,10,11,12,13,14,15,16,21,33,34,35,36,39,57,63,65,72,73,74,75,77,78,79}
local function yes(v) return v==true or v==1 end
local function over(x,y,w,h) return MousePosX()>=x and MousePosX()<=x+w and MousePosY()>=y and MousePosY()<=y+h end
function Q.Blocked()
    if UICustomInterface and UICustomInterface~=0 then return true end
    for _,id in ipairs(native) do if CheckWindowOpen(id)==1 then return true end end
    if Shop and Shop.IsOpen and yes(Shop.IsOpen()) then return true end
    if QuestSystem and QuestSystem.CheckOpen and yes(QuestSystem.CheckOpen()) then return true end
    if GuardiaoBrindes and GuardiaoBrindes.CheckOpen and yes(GuardiaoBrindes.CheckOpen()) then return true end
    if LogInAndWinVisible==1 then return true end
    for _,check in ipairs(C.ExtraWindowChecks) do if yes(check()) then return true end end
    return false
end
function Q.CheckOpen() return S.Open and 1 or 0 end
function Q.ButtonVisible() return false end
local function bar(x,y,w,h,c)
    EnableAlphaTest(); SetBlend(); glColor4f(unpack(c)); DrawBar(x,y,w,h); EndDrawBar()
    GLSwitchBlend(); GLSwitch(); glColor3f(1,1,1); DisableAlphaBlend()
end
local function text(x,y,label,w,c,align)
    EnableAlphaTest(); SetFontType(1); SetTextBg(0,0,0,0); SetTextColor(c[1],c[2],c[3],255)
    RenderText3(x,y,tostring(label),w,align or 1); DisableAlphaBlend()
end
local function frame(x,y,w,h,selected)
    bar(x,y,w,h,selected and {.58,.44,.23,1} or {.31,.25,.14,1})
    bar(x+1,y+1,w-2,h-2,{.105,.085,.055,.98})
    bar(x+2,y+2,w-4,1,{.39,.31,.17,.7})
end
local function button(x,y,w,h,label,enabled,action,selected,blocked)
    frame(x,y,w,h,selected or (enabled and over(x,y,w,h)))
    bar(x+2,y+2,w-4,h-4,enabled and {.25,.19,.10,.9} or {.12,.11,.08,.9})
    text(x+2,y+(h-10)/2,label,w-4,enabled and gold or muted,3)
    if enabled and not blocked then controls[#controls+1]={X=x,Y=y,W=w,H=h,Action=action} end
end
local function wrapped(x,y,label,width,maxlines,color)
    local line,lines='',0
    local maxchars=math.max(10,math.floor(width/4.5))
    for word in tostring(label or ''):gmatch('%S+') do
        if #line+#word+1>maxchars and line~='' then
            text(x,y+lines*11,line,width,color); lines=lines+1; line=''
            if lines>=maxlines then return end
        end
        line=line=='' and word or line..' '..word
    end
    if line~='' and lines<maxlines then text(x,y+lines*11,line,width,color) end
end
function Q.Close()
    if not S.Open then return end
    S.Open=false; S.Waiting=false; S.Sequence=S.Sequence+1; controls={}; incoming=nil
    DisableClickClient(); SetUnlockInterfaces()
end
function Q.Request(action,id)
    if not S.Open or S.Waiting or Q.Blocked() then return end
    S.Sequence=S.Sequence%2147483646+1; incoming={List=action==1 and {} or S.List,ExpectedQuests=S.ExpectedQuests}; S.Waiting=true; S.Sent=os.time(); S.LastAction=action
    local n='QuestV2Request-'..UserGetName()
    CreatePacket(n,0x04); SetBytePacket(n,action); SetDwordPacket(n,S.Sequence)
    SetDwordPacket(n,id or S.Selected); SetDwordPacket(n,S.Run or 0)
    SendPacket(n); ClearPacket(n)
end
function Q.Open()
    if not C.Enabled or Q.Blocked() then return end
    S.Name=UserGetName(); S.Open=true; S.Waiting=false; S.List={}; S.Rows={}; S.Rewards={}; S.Selected=0; S.Run=0
    S.Page=0; S.ListPage=0; S.RewardPage=0; S.Message='Carregando quests...'; S.Ready=false; S.Valid=false; S.State=0; S.Pending=0; S.ExpectedQuests=0
    controls={}; SetLockInterfaces(); DisableClickClient(); Q.Request(1,0)
end
local function readstr(n)
    local length=GetBytePacket(n,-1)
    return GetCharPacketLength(n,-1,length)
end
local itemOptions={'Op1','Op2','Life','Exc','Ancient','JoH','SocketBonus','Sock1','Sock2','Sock3','Sock4','Sock5'}
function Q.Protocol(number,n)
    if number~=0x04 or n~='QuestV2-'..UserGetName() then return end
    local sequence,kind=GetDwordPacket(n,-1),GetBytePacket(n,-1)
    if not S.Open or not S.Waiting or sequence~=S.Sequence or Q.Blocked() then ClearPacket(n); return true end
    local next=incoming
    if kind==1 then next.List={}; next.ExpectedQuests=GetBytePacket(n,-1)
    elseif kind==2 then
        next.List[#next.List+1]={ID=GetDwordPacket(n,-1),Name=readstr(n),Description=readstr(n),Repeatable=GetBytePacket(n,-1)==1}
    elseif kind==3 then
        next.Selected=GetDwordPacket(n,-1); next.Run=GetDwordPacket(n,-1); next.State=GetBytePacket(n,-1); next.Ready=GetBytePacket(n,-1)==1
        next.Active=GetDwordPacket(n,-1); next.ExpectedRows=GetBytePacket(n,-1); next.Pending=GetBytePacket(n,-1)
        next.Rows={}; next.Rewards={}; next.Snapshot=true
    elseif kind==4 and next.Snapshot then
        next.Rows[#next.Rows+1]={Label=readstr(n),Current=GetDwordPacket(n,-1),Required=GetDwordPacket(n,-1),Time=GetBytePacket(n,-1)==1}
    elseif kind==5 and next.Snapshot then
        next.Rewards[#next.Rewards+1]={Name=readstr(n),Count=GetDwordPacket(n,-1),Item=GetWordPacket(n,-1),Level=GetBytePacket(n,-1)}
    elseif kind==8 and next.Snapshot then
        local ordinal=GetWordPacket(n,-1)
        local reward=next.Rewards[ordinal]
        if reward then for _,key in ipairs(itemOptions) do reward[key]=GetDwordPacket(n,-1) end end
    elseif kind==6 then
        local message=readstr(n)
        S.Waiting=false; S.LastUpdate=os.time()
        if next.Snapshot and #next.Rows==next.ExpectedRows and #next.List==next.ExpectedQuests then
            if next.Selected~=S.Selected then S.Page=0; S.RewardPage=0 end
            for _,key in ipairs({'List','ExpectedQuests','Selected','Run','State','Ready','Active','Pending','Rows','Rewards'}) do S[key]=next[key] end
            S.Page=math.min(S.Page,math.max(0,math.ceil(#S.Rows/5)-1))
            S.RewardPage=math.min(S.RewardPage,math.max(0,math.ceil(#S.Rewards/3)-1))
            S.Valid=true
            -- Successful reads remove transient loading/timeout messages.
            if message~='' or S.LastAction==1 or S.LastAction==4 then S.Message=message end
        else
            S.Valid=false
            S.Message=message~='' and message or 'Atualizacao incompleta. Tentando novamente...'
        end
        incoming=nil
    end
    ClearPacket(n); return true
end
local function duration(seconds)
    return string.format('%dh %02dm',math.floor(seconds/3600),math.floor(seconds/60)%60)
end
local function rowCount(row)
    if row.Time then return duration(row.Current)..' / '..duration(row.Required) end
    return row.Current..' / '..row.Required
end
function Q.UpdateProc()
    if not C.Enabled then Q.Close(); return end
    local name=UserGetName()
    if S.Name~=name then
        Q.Close(); S.Name=name; S.List={}; S.Rows={}; S.Rewards={}
    end
    if not S.Open then return end
    if Q.Blocked() then Q.Close(); return end
    if S.Waiting and os.time()-S.Sent>=6 then
        S.Waiting=false; incoming=nil; S.Valid=false; S.Message='Sem resposta. Tentando atualizar...'; S.LastUpdate=os.time()
    end
    if not S.Waiting and os.time()-(S.LastUpdate or 0)>=C.RefreshSeconds then Q.Request(#S.List==0 and 1 or 4) end
end
function Q.Render()
    controls={}; Q.UpdateProc()
    if not C.Enabled then return end
    if not S.Open then return end
    local w=C.Window; local x,y=w.X,w.Y
    frame(x,y,w.W,w.H,true)
    bar(x+4,y+4,w.W-8,19,{.28,.20,.10,1})
    text(x+10,y+8,'Sistema de Quest',w.W-40,gold)
    local closeX,closeY=x+w.W-29,y+4
    local closeHover=over(closeX,closeY,24,20)
    frame(closeX,closeY,24,20,closeHover)
    bar(closeX+2,closeY+2,20,16,closeHover and {.48,.13,.08,1} or {.25,.19,.10,1})
    -- Larger cross independent of the client's small default text font.
    for i=0,6 do
        bar(closeX+7+i*1.4,closeY+5+i*1.4,1.8,1.8,{.94,.84,.62,1})
        bar(closeX+7+i*1.4,closeY+13.4-i*1.4,1.8,1.8,{.94,.84,.62,1})
    end
    controls[#controls+1]={X=closeX,Y=closeY,W=24,H=20,Action=Q.Close}
    if closeHover then text(closeX-66,closeY+23,'Fechar (Esc)',90,gold,3) end
    local sidebar=94; local cx=x+sidebar+12; local cw=w.W-sidebar-19
    frame(x+5,y+28,sidebar,w.H-35)
    local first=S.ListPage*6+1
    for i=first,math.min(first+5,#S.List) do
        local entry=S.List[i]; local yy=y+32+(i-first)*31
        button(x+8,yy,sidebar-6,28,entry.Name:sub(1,21),not S.Waiting or S.LastAction==4,function() Q.Request(4,entry.ID) end,S.Selected==entry.ID,S.Waiting)
    end
    if #S.List>6 then
        button(x+9,y+w.H-32,22,17,'<',S.ListPage>0,function() S.ListPage=S.ListPage-1 end)
        button(x+sidebar-22,y+w.H-32,22,17,'>',first+5<#S.List,function() S.ListPage=S.ListPage+1 end)
    end
    local selected
    for _,v in ipairs(S.List) do if v.ID==S.Selected then selected=v end end
    frame(cx,y+28,cw,49)
    text(cx+7,y+34,selected and selected.Name or 'Carregando...',cw-14,gold)
    wrapped(cx+7,y+48,selected and selected.Description or '',cw-14,2,white)
    local status=({[0]='Nao iniciada',[1]='Em andamento',[2]='Concluida',[3]='Resgate em conferencia',[4]='Nao iniciada'})[S.State] or ''
    local info=status..(selected and (selected.Repeatable and ' | Repetivel' or ' | Uma vez por personagem') or '')
    if S.Message and S.Message~='' then info=S.Message end
    text(cx+7,y+80,info,cw-14,S.Ready and green or muted)
    frame(cx,y+94,cw,103)
    text(cx+4,y+99,'Tarefas a serem realizadas',cw-8,gold,3)
    local start=S.Page*5+1
    for i=start,math.min(start+4,#S.Rows) do
        local r=S.Rows[i]; local yy=y+116+(i-start)*13
        local complete=r.Current>=r.Required
        local color=complete and green or white
        text(cx+5,yy,complete and '+' or '-',8,color)
        text(cx+14,yy,rowCount(r),110,color)
        text(cx+126,yy,r.Label:sub(1,34),cw-130,color)
    end
    if #S.Rows>5 then
        button(cx+5,y+179,19,14,'<',S.Page>0,function() S.Page=S.Page-1 end)
        text(cx+26,y+182,(S.Page+1)..' / '..math.ceil(#S.Rows/5),cw-52,muted,3)
        button(cx+cw-24,y+179,19,14,'>',start+4<#S.Rows,function() S.Page=S.Page+1 end)
    end
    frame(cx,y+203,cw,65)
    text(cx+4,y+207,'Recompensas',cw-8,gold,3)
    local hovered
    local icons={}
    local rf=S.RewardPage*3+1
    local visible=math.min(3,#S.Rewards-rf+1)
    for i=rf,math.min(rf+2,#S.Rewards) do
        local v=S.Rewards[i]; local cell=(cw-44)/visible; local rx=cx+22+(i-rf)*cell
        if v.Item~=65535 then
            local ix,iy=rx+cell/2-13,y+228
            icons[#icons+1]={X=ix,Y=iy,Item=v}
            if over(ix,iy,26,25) then hovered=v end
        end
        text(rx,y+255,v.Count..'x '..v.Name:sub(1,16),cell,gold,3)
    end
    if #S.Rewards>3 then
        button(cx+3,y+232,14,16,'<',S.RewardPage>0,function() S.RewardPage=S.RewardPage-1 end)
        button(cx+cw-17,y+232,14,16,'>',rf+2<#S.Rewards,function() S.RewardPage=S.RewardPage+1 end)
    end
    local label,enabled,action='Iniciar quest',S.Valid and (not S.Active or S.Active==0),2
    if S.State==1 then label='Resgatar recompensa'; enabled=S.Ready; action=3
    elseif S.State==3 then label='Resgate em conferencia'; enabled=false
    elseif S.State==2 and (S.Pending or 0)>0 then label='Retirar premio'; enabled=S.Pending~=255; action=5
    elseif S.State==2 then label=selected and selected.Repeatable and 'Iniciar novamente' or 'Quest concluida'; enabled=selected and selected.Repeatable and (not S.Active or S.Active==0) end
    button(cx+(cw-138)/2,y+274,138,20,S.Waiting and S.LastAction~=4 and 'Aguarde...' or label,enabled and S.Valid and (not S.Waiting or S.LastAction==4),function() Q.Request(action) end,nil,S.Waiting)
    -- Draw models after the panel; ShowDescriptionComplete uses the native item data.
    for _,icon in ipairs(icons) do
        DisableAlphaBlend()
        CreateItem(icon.X,icon.Y,26,25,icon.Item.Item,icon.Item.Level,icon.Item.Exc or 0,icon.Item.Ancient or 0,1)
    end
    if hovered then
        local options={}
        for _,key in ipairs(itemOptions) do options[#options+1]=hovered[key] or 0 end
        EnableAlphaTest(); glColor4f(1,1,1,1)
        ShowDescriptionComplete(MousePosX()+20,MousePosY(),hovered.Item,hovered.Level,unpack(options))
        DisableAlphaBlend()
    end
end
function Q.UpdateMouse()
    if not S.Open then controls={}; return end
    if Q.Blocked() then if S.Open then Q.Close() end; return end
    if S.Open then SetLockInterfaces() end
    for _,b in ipairs(controls) do
        if over(b.X,b.Y,b.W,b.H) then
            if CheckClickClient()==1 then DisableClickClient(); b.Action(); controls={}; return end
        end
    end
    if S.Open then DisableClickClient() end
end
function Q.UpdateKeyEvent()
    local pressed=CheckPressedKey(C.Shortcut)==1
    local held=pressed or (CheckRepeatKey and CheckRepeatKey(C.Shortcut)==1)
    local toggle=pressed and not shortcutDown
    shortcutDown=held
    if not C.Enabled then return end
    if Q.Blocked() then if S.Open then Q.Close() end; return end
    if S.Open and CheckPressedKey(Keys.Escape)==1 then Q.Close(); return end
    if toggle then
        -- DisableClickClient also sets gInterface.interfaceLock, preventing the
        -- native UpdateKey handler from handling the same key (source verified).
        DisableClickClient()
        if S.Open then Q.Close() else Q.Open() end
    end
end
InterfaceController.ClientProtocol(Q.Protocol)
-- Same drawing phase used by the client Shop item models.
InterfaceController.BeforeMainProc(Q.Render)
InterfaceController.UpdateMouse(Q.UpdateMouse)
InterfaceController.UpdateKey(Q.UpdateKeyEvent)
InterfaceController.UpdateProc(Q.UpdateProc)
return Q
