CUSTOM_MONSTER_NAME_INFO = {
	
    { Class = 400, Map = 0, CoordX = 125, CoordY = 125, Name = "Guardião dos Tesouros" },
    { Class = 401, Map = 0, CoordX = 125, CoordY = 125, Name = "Guardião de Brindes" },
    { Class = 410, Map = 0, CoordX = 125, CoordY = 125, Name = "Spooky Monster" },
    { Class = 411, Map = -1, CoordX = -1, CoordY = -1, Name = "Coelho Assassin" },
    { Class = 245, Map = -1, CoordX = -1, CoordY = -1, Name = "NPC-MOVE" },
    { Class = 413, Map = 0, CoordX = 125, CoordY = 125, Name = "Crazzy Santa" },
    { Class = 414, Map = 0, CoordX = 125, CoordY = 125, Name = "Armaggedon Mix" },
    { Class = 415, Map = 0, CoordX = 125, CoordY = 125, Name = "GamePlay Keeper" },
    { Class = 420, Map = 96, CoordX = 125, CoordY = 125, Name = "Shadow Worker" },
    { Class = 421, Map = 96, CoordX = 125, CoordY = 125, Name = "Hunter Black" },
    { Class = 424, Map = 96, CoordX = 125, CoordY = 125, Name = "Ur Blue" },

}


function StartLoadCustomMonsterName()
    for i = 1, #CUSTOM_MONSTER_NAME_INFO do
        monsterInfo = CUSTOM_MONSTER_NAME_INFO[i]

        SetCustomMonsterName(monsterInfo.Class, monsterInfo.Map, monsterInfo.CoordX, monsterInfo.CoordY, monsterInfo.Name)
    end
end

StartLoadCustomMonsterName()