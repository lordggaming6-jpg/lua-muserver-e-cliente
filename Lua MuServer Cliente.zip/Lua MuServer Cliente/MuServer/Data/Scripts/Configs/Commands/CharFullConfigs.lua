--Configura��es Comando Char Full

CHARFULL_COMMAND = "/full"
CHARFULL_COMMAND_SWITCH = 1
CHARFULL_MAX_USE = 10
CHARFULL_TABLE = "MEMB_INFO"
CHARFULL_COLUMN = "CharFull"
CHARFULL_WHERE = "memb___id"







