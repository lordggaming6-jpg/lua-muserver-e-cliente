-- Instale primeiro Scripts/SQL/Convert-JewelCash.sql no banco do GameServer.
ConvertJewelCashConfig = {
    Enabled = true, -- ative somente depois de configurar e testar
    Packet = 220, -- igual ao cliente; reserve este numero no servidor
    Cooldown = 2,
    Entries = {
        -- Section e Index do item; Level = -1 aceita qualquer level.
        -- Owner: "Account" usa a conta, "Character" usa o nome do personagem.
        {Section = 14, Index = 226, Level = -1, Amount = 250, CurrencyName = "Gold's",
            Table = "CashShopData", Schema = "dbo", Column = "WCoinP", KeyColumn = "AccountID", Owner = "Account"},
			
         {Section = 14, Index = 225, Level = -1, Amount = 500, CurrencyName = "Gold's",
             Table = "CashShopData", Schema = "dbo", Column = "WCoinP", KeyColumn = "AccountID", Owner = "Account"},

         {Section = 14, Index = 224, Level = -1, Amount = 1000, CurrencyName = "Gold's",
             Table = "CashShopData", Schema = "dbo", Column = "WCoinP", KeyColumn = "AccountID", Owner = "Account"},
 			 
			 
    },
}
