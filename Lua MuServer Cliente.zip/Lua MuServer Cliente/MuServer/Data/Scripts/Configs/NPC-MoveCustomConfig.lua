-- Configure cada comando em Configs/Commands/MoveCustomConfig.lua.
NPCMoveCustomConfig = {
    Enabled = true, -- altere para true depois de configurar os exemplos
    Packet = 219, -- deve ser igual ao cliente; reserve o numero
    MissingMessage = "Voce nao possui o item necessario para Mover.",
    UnavailableMessage = "Move indisponivel. Confira o Item necessario para Mover.",
    Entries = {
        -- NPCs existentes: NpcClass e o indice do Monster.txt. NpcMap = -1: qualquer mapa.
        {Mode = "NPC", NpcClass = 245, NpcMap = 2, Command = "/arena1",
            Item = {Required = true, Section = 14, Index = 267, Level = -1}},
			
        {Mode = "NPC", NpcClass = 245, NpcMap = 2, Command = "/arena1",
            Item = {Required = true, Section = 14, Index = 267, Level = -1}},
			
        -- Exemplos de uso direto: Ctrl + botao direito no item. Descomente para ativar.
         {Mode = "ITEM", Command = "/halloween", Item = {Required = true, Section = 14, Index = 268, Level = -1}},
        -- {Mode = "ITEM", Command = "/arena2", Item = {Required = true, Section = 14, Index = 16, Level = -1}},
    },
}
