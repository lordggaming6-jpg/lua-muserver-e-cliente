-- QUEST V2: progresso e historico sempre registrados no banco MuOnline.
-- Execute MuServer/SQL/QuestV2.sql antes de iniciar o GameServer.
-- Configuracao da apresentacao/botao: QuestSystemNpc.lua no CLIENTE.
QuestWindowConfig = {
    ResumeOnLogin = true, -- true: continua apos reconectar; false: abandona ao sair
    SaveInterval = 30, -- segundos entre checkpoints; logout normal salva imediatamente
    Packet = 0x04,
}
-- Em CADA entrada de QUEST_SYSTEM_NPC_INFO:
-- Repeatable = false: pode concluir UMA vez por personagem; true: varias vezes.
-- OnlineSeconds = 86400: exige 24 horas ONLINE acumuladas desde Iniciar Quest.
-- OnlineSeconds = 0: sem exigencia de tempo. Tempo offline nunca conta.
-- Requisitos Reset/MReset/Level continuam verificando o valor atual do personagem.
-- Uma quest ativa por personagem. Trocar de aba nao cancela a quest ativa.
-- Opcoes legadas ONLY_ACCOUNT, ONLY_ONE_QUEST, LOCATION_INFO, Validity,
-- DaysExpire e PACKET_*_NAME abaixo nao controlam a V2.
-- ONLY_ACCOUNT foi substituido por registro por personagem e ONLY_ONE_QUEST
-- por Repeatable em cada quest. Validity ja nao era aplicada pelo sistema original.
-- Nao remova/reutilize IDs de quests em andamento; altere regras com servidor parado.

QUEST_SYSTEM_NPC_SWITCH = 1
QUEST_SYSTEM_NPC_ONLY_ACCOUNT = 0 -- se = 1, a quest será apenas por conta, se for 0, é por personagem
QUEST_SYSTEM_NPC_REMOVE_RESETS = 0
QUEST_SYSTEM_NPC_REMOVE_MRESETS = 0
QUEST_SYSTEM_NPC_REMOVE_COIN1 = 0
QUEST_SYSTEM_NPC_REMOVE_COIN2 = 0
QUEST_SYSTEM_NPC_REMOVE_COIN3 = 0
QUEST_SYSTEM_NPC_ONLY_ONE_QUEST = 0 -- se = 1, quando o jogador inicia uma missão e cancela ou termina ele não pode começar novamente

-- Npc Identification
QUEST_SYSTEM_NPC_LOCATION_INFO = {}
QUEST_SYSTEM_NPC_LOCATION_INFO = {
    --{ Class = 245, Map = 0, CoordX = 137, CoordY = 140, QuestIdentification = 1 },
    --{ Class = 245, Map = 0, CoordX = 130, CoordY = 125, QuestIdentification = 2 },
}

-- Identification of the quest
QUEST_SYSTEM_NPC_INFO = {}
QUEST_SYSTEM_NPC_INFO = {
    -- QUEST OF LORENCIA
    { QuestIdentification = 1, Repeatable = false, OnlineSeconds = 0, Description = 'Evolua e de Resets e Mr e conclua os requisitos para receber sua recompensa.', Level = 400, Reset = 150, MReset = 8, Zen = 0, Coin1 = 0, Coin2 = 0, Coin3 = 0, Vip = 0, Kills = 0, QuestName = 'Quest 1 MU Zyron-X', Validity = '30/02/2027' },
    { QuestIdentification = 2, Repeatable = false, OnlineSeconds = 86400, Description = 'Fique Online e de Resets e Mr e conclua os requisitos para receber sua recompensa.', Level = 400, Reset = 0, MReset = 0, Zen = 0, Coin1 = 0, Coin2 = 0, Coin3 = 0, Vip = 0, Kills = 0, QuestName = 'Quest 2 MU Zyron-X', Validity = '30/02/2027' },
	
}

-- PARTE ONDE VOCÊ COLOCA OS ITENS NECESSÁRIO PARA CADA QUEST
QUEST_SYSTEM_NPC_REQUIREMENTS_ITEMS = {}
QUEST_SYSTEM_NPC_REQUIREMENTS_ITEMS[1] = {
    --{ ItemIndex = GET_ITEM(7, 0), Level = 15, Luck = -1, Skill = -1, Quantity = 1 },
    --{ ItemIndex = GET_ITEM(8, 0), Level = 15, Luck = -1, Skill = -1, Quantity = 1 },
    --{ ItemIndex = GET_ITEM(9, 0), Level = 15, Luck = -1, Skill = -1, Quantity = 1 },
    --{ ItemIndex = GET_ITEM(10, 0), Level = 15, Luck = -1, Skill = -1, Quantity = 1 },
    --{ ItemIndex = GET_ITEM(11, 0), Level = 15, Luck = -1, Skill = -1, Quantity = 1 },
    --{ ItemIndex = GET_ITEM(13, 212), Level = 15, Luck = -1, Skill = -1, Quantity = 1 },
}

-- PARTE ONDE VOCÊ COLOCA A QUANTIDADE DE MONSTROS NECESSÁRIOS (MÁXIMO 9)
QUEST_SYSTEM_NPC_REQUIREMENTS_MONSTER = {}
-- [1] = QUEST OF LORENCIA
QUEST_SYSTEM_NPC_REQUIREMENTS_MONSTER[1] = {
    { MonsterIndex = 4, Quantity = 10, Name = 'Mate Bull Fighter em Arena' },
}

-- MOEDAS PERSONALIZADAS NO BANCO DE DADOS
-- Confirme que memb___id identifica a conta na sua tabela MEMB_INFO.
QUEST_SYSTEM_NPC_CURRENCIES = {
    Cash = {
        Name = 'Cash', Database = 'MuOnline', Schema = 'dbo',
        Table = 'MEMB_INFO', Column = 'cash',
        KeyColumn = 'memb___id', Owner = 'Account',
    },
}

-- REQUISITO EM MOEDA DESATIVADO: nao exige cash para esta quest.
QUEST_SYSTEM_NPC_REQUIREMENTS_CURRENCIES = {}

-- Reward player: moedas
-- CoinIdentification: 1 = WcoinC, 2 = WcoinP, 3 = GlobinPoint
QUEST_SYSTEM_NPC_REWARD_COINS = {}
-- [1] = QuestIdentification
QUEST_SYSTEM_NPC_REWARD_COINS[1] = {
    --{ Currency = 'Cash', CoinAmount = 50 },
    --{ CoinName = 'hpoints', CoinAmount = 50, CoinIdentification = 1 },
}

--[[
ItemTime: 0 = Eterno, tempo em segundos
DaysExpire: momento o item poderá ficar no npc de resgate, após a pessoa não poder mais retirar
Class: -1 = todas as classes
]]--
QUEST_SYSTEM_NPC_REWARD_ITEMS = {}
QUEST_SYSTEM_NPC_REWARD_ITEMS[1] = {
    { ItemIndex = GET_ITEM(14, 248), Level = 0, Op1 = 0, Op2 = 0, Life = 0, Exc = 0, Ancient = 255, JoH = 255, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, ItemTime = 0, DaysExpire = 0, Name = 'Bloody Reward', Count = 2, Class = -1 },
}
QUEST_SYSTEM_NPC_REWARD_ITEMS[2] = {
    { ItemIndex = GET_ITEM(0, 54), Level = 15, Op1 = 1, Op2 = 1, Life = 7, Exc = 63, Ancient = 255, JoH = 255, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, ItemTime = 0, DaysExpire = 0, Name = 'Sword Of Style', Count = 2, Class = -1 },	
	
}

-- Buffs: o efeito é contabilizado por segundos
QUEST_SYSTEM_NPC_REWARD_BUFF = {}
--QUEST_SYSTEM_NPC_REWARD_BUFF[1] = {
--    { EffectID = 29, EffectTime = 3600, BuffName = 'BUFF TOP QUEST' }
--}

QUEST_SYSTEM_NPC_PACKET = 0x04
QUEST_SYSTEM_NPC_PACKET_OPEN_NAME = 'QuestSystemNpcOpen'
QUEST_SYSTEM_NPC_PACKET_START_NAME = 'QuestSystemNpcStartQuest'
QUEST_SYSTEM_NPC_PACKET_GET_REWARD_NAME = 'QuestSystemNpcGetReward'
QUEST_SYSTEM_NPC_PACKET_DISMISS_QUEST_NAME = 'QuestSystemNpcDismissQuest'
QUEST_SYSTEM_NPC_PACKET_FINISHED_QUEST_NAME = 'QuestSystemNpcFinished'

QUEST_SYSTEM_NPC_MESSAGES = {}
QUEST_SYSTEM_NPC_MESSAGES['Por'] = {
[1] = 'Você está ocupado no momento!',
[2] = 'Não encontramos nenhuma quest disponível no momento!',
[3] = 'Você iniciou a quest %s!',
[4] = 'Não conseguimos identificar a sua quest!',
[5] = 'Você já está com uma quest ativa!',
[6] = 'Você precisa concluir todos os requisitos!',
[7] = 'Você recebeu %d %s',
[8] = 'Você já concluiu todas as quests!',
[9] = '%s - %s (%d/%d)',
[10] = 'Você foi premiado com: %d %s',
}
QUEST_SYSTEM_NPC_MESSAGES['Eng'] = {
[1] = 'Você está ocupado no momento!',
[2] = 'Não encontramos nenhuma quest disponível no momento!',
[3] = 'Você iniciou a quest %s!',
[4] = 'Não conseguimos identificar a sua quest!',
[5] = 'Você já está com uma quest ativa!',
[6] = 'Você precisa concluir todos os requisitos!',
[7] = 'Você recebeu %d %s',
[8] = 'Você já concluiu todas as quests!',
[9] = '%s - %s (%d/%d)',
[10] = 'Você foi premiado com: %d %s',
}
QUEST_SYSTEM_NPC_MESSAGES['Spn'] = {
[1] = 'Você está ocupado no momento!',
[2] = 'Não encontramos nenhuma quest disponível no momento!',
[3] = 'Você iniciou a quest %s!',
[4] = 'Não conseguimos identificar a sua quest!',
[5] = 'Você já está com uma quest ativa!',
[6] = 'Você precisa concluir todos os requisitos!',
[7] = 'Você recebeu %d %s',
[8] = 'Você já concluiu todas as quests!',
[9] = '%s - %s (%d/%d)',
[10] = 'Você foi premiado com: %d %s',
}
