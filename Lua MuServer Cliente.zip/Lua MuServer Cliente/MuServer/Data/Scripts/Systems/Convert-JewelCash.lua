-- Conversao de item para saldo; nenhum destino vem do cliente.
ConvertJewelCash = {}
local C = ConvertJewelCashConfig
local busy, last = {}, {}
local function log(s) LogAddC(2, '[Convert-JewelCash] ' .. s) end
local function quote(s) return "'" .. tostring(s):gsub("'", "''") .. "'" end
local function ident(s)
    if type(s) ~= 'string' or #s > 128 or not s:match('^[A-Za-z_][A-Za-z0-9_]*$') then return nil end
    return '[' .. s .. ']'
end
local function integer(v, low, high)
    return type(v) == 'number' and v == math.floor(v) and v >= low and v <= high
end
local function valid(e)
    return type(e) == 'table' and integer(e.Section, 0, 15) and integer(e.Index, 0, 511)
        and integer(e.Level, -1, 15) and integer(e.Amount, 1, 2147483647)
        and (e.Owner == 'Account' or e.Owner == 'Character')
        and ident(e.Schema) and ident(e.Table) and ident(e.Column) and ident(e.KeyColumn)
        and type(e.CurrencyName) == 'string' and #e.CurrencyName > 0 and #e.CurrencyName <= 40
end
local function ready(p)
    return p:getConnected() >= 3 and p:getType() == 1 and p:getLive() == 1
        and p:getTeleport() == 0 and p:getDieRegen() == 0
        and p:getInterfaceUse() == 0 and p:getInterfaceType() == 0 and p:getShopOpen() == 0
        and (not p.getUsingTradeX or p:getUsingTradeX() == 0)
end
local function query(sql)
    local ok, result, operation = pcall(function()
        local db = DataBase.getDb()
        if db:exec(sql) == 0 then db:clear(); return nil end
        if db:fetch() == SQL_NO_DATA then db:clear(); return nil end
        local r, id = db:getInt('Result'), db:getInt('Operation')
        db:clear()
        return r, id
    end)
    if not ok then
        pcall(function() DataBase.getDb():clear() end)
        return nil
    end
    return result, operation
end
local function location(e) return ident(e.Schema) .. '.' .. ident(e.Table) end
local function transactionStart(account)
    return "SET NOCOUNT ON; SET XACT_ABORT ON; BEGIN TRY BEGIN TRANSACTION; DECLARE @l int; EXEC @l=sys.sp_getapplock @Resource=" ..
        quote('ConvertJewelCash:' .. account) .. ", @LockMode='Exclusive', @LockOwner='Transaction', @LockTimeout=3000; IF @l<0 RAISERROR('lock',16,1); "
end
local function transactionEnd()
    return ' END TRY BEGIN CATCH IF @@TRANCOUNT>0 ROLLBACK; SELECT -1 AS Result, 0 AS Operation; END CATCH;'
end
local function reserve(p, e, slot, itemIndex, level, serial, quantity)
    local account, character = p:getAccountID(), p:getName()
    local owner = e.Owner == 'Account' and account or character
    local tableName, column, key = location(e), ident(e.Column), ident(e.KeyColumn)
    local where = key .. '=' .. quote(owner)
    local sql = transactionStart(account) ..
        'IF EXISTS(SELECT 1 FROM dbo.ConvertJewelCashJournal WITH(UPDLOCK,HOLDLOCK) WHERE AccountId=' .. quote(account) ..
        ' AND State=0) BEGIN ROLLBACK; SELECT 2 AS Result, 0 AS Operation; RETURN; END; ' ..
        'DECLARE @n bigint, @balance bigint; SELECT @n=COUNT_BIG(*), @balance=MIN(CASE WHEN ' .. column ..
        ' BETWEEN 0 AND 2147483647 AND ' .. column .. '=FLOOR(' .. column .. ') THEN CONVERT(bigint,' .. column ..
        ') ELSE -1 END) FROM ' .. tableName .. ' WITH(UPDLOCK,HOLDLOCK) WHERE ' .. where .. '; ' ..
        'IF @n<>1 OR @balance IS NULL OR @balance<0 OR @balance+' .. e.Amount ..
        '>2147483647 BEGIN ROLLBACK; SELECT 3 AS Result, 0 AS Operation; RETURN; END; ' ..
        'INSERT dbo.ConvertJewelCashJournal(AccountId,CharacterName,ItemIndex,ItemLevel,ItemSerial,ItemSlot,QuantityBefore,' ..
        'CurrencySchema,CurrencyTable,CurrencyColumn,CurrencyKeyColumn,CurrencyOwner,Amount) VALUES(' ..
        quote(account) .. ',' .. quote(character) .. ',' .. itemIndex .. ',' .. level .. ',' .. quote(serial) .. ',' ..
        slot .. ',' .. quantity .. ',' .. quote(e.Schema) .. ',' .. quote(e.Table) .. ',' .. quote(e.Column) .. ',' ..
        quote(e.KeyColumn) .. ',' .. quote(owner) .. ',' .. e.Amount .. '); DECLARE @id int=CONVERT(int,SCOPE_IDENTITY()); ' ..
        'COMMIT; SELECT 1 AS Result, @id AS Operation;' .. transactionEnd()
    return query(sql)
end
local function credit(p, e, operation)
    local account = p:getAccountID()
    local owner = e.Owner == 'Account' and account or p:getName()
    local col, key = ident(e.Column), ident(e.KeyColumn)
    local sql = transactionStart(account) ..
        'IF NOT EXISTS(SELECT 1 FROM dbo.ConvertJewelCashJournal WITH(UPDLOCK,HOLDLOCK) WHERE Id=' .. operation ..
        ' AND State=0 AND AccountId=' .. quote(account) .. ') BEGIN ROLLBACK; SELECT 2 AS Result, 0 AS Operation; RETURN; END; ' ..
        'UPDATE ' .. location(e) .. ' SET ' .. col .. '=' .. col .. '+' .. e.Amount .. ' WHERE ' .. key .. '=' .. quote(owner) ..
        ' AND ' .. col .. ' BETWEEN 0 AND ' .. (2147483647 - e.Amount) .. '; ' ..
        'IF @@ROWCOUNT<>1 BEGIN ROLLBACK; SELECT 3 AS Result, 0 AS Operation; RETURN; END; ' ..
        'UPDATE dbo.ConvertJewelCashJournal SET State=1,CompletedAt=GETUTCDATE() WHERE Id=' .. operation ..
        ' AND State=0 AND AccountId=' .. quote(account) .. '; ' ..
        'IF @@ROWCOUNT<>1 BEGIN ROLLBACK; SELECT 2 AS Result, 0 AS Operation; RETURN; END; ' ..
        'COMMIT; SELECT 1 AS Result, ' .. operation .. ' AS Operation;' .. transactionEnd()
    return query(sql)
end
local function consume(inv, index, slot, serial, itemIndex, level, quantity)
    if inv:isItem(slot) == 0 or inv:getSerial(slot) ~= serial or inv:getIndex(slot) ~= itemIndex
        or inv:getLevel(slot) ~= level then return false end
    if GetStackItem(itemIndex) > 0 and inv:getDurability(slot) ~= quantity then return false end
    if GetStackItem(itemIndex) > 0 and quantity > 1 then
        inv:setDurability(slot, quantity - 1)
        inv:convertItem(slot)
        ItemListSend(index)
        return inv:isItem(slot) ~= 0 and inv:getSerial(slot) == serial and inv:getDurability(slot) == quantity - 1
    end
    InventoryDeleteItem(index, slot)
    SendInventoryDeleteItem(index, slot)
    return inv:isItem(slot) == 0
end
local function convert(index, slot, p, inv, e)
    local itemIndex, level, serial = inv:getIndex(slot), inv:getLevel(slot), inv:getSerial(slot)
    local quantity = GetStackItem(itemIndex) > 0 and inv:getDurability(slot) or 1
    if not integer(quantity, 1, 255) or serial == nil then return end
    local account = p:getAccountID()
    if type(account) ~= 'string' or #account == 0 or #account > 64 or #p:getName() > 64 then return end
    local result, operation = reserve(p, e, slot, itemIndex, level, tostring(serial), quantity)
    if result ~= 1 or not integer(operation, 1, 2147483647) then
        SendMessage(result == 2 and 'Conversao pendente; procure a administracao.' or 'Conversao indisponivel. Procure a administracao.', index, 1)
        log('Reserva nao confirmada ou conta pendente.'); return
    end
    local ok, removed = pcall(consume, inv, index, slot, serial, itemIndex, level, quantity)
    if not ok or not removed then
        log('Operacao pendente #' .. operation .. ': confira o item antes de liberar.')
        SendMessage('Conversao pendente; procure a administracao.', index, 1); return
    end
    local credited = credit(p, e, operation)
    if credited ~= 1 then
        log('Operacao pendente ou resposta SQL incerta #' .. operation .. ': confira saldo e inventario.')
        SendMessage('Conversao pendente; procure a administracao.', index, 1); return
    end
    SendMessage(string.format('Voce recebeu %d %s.', e.Amount, e.CurrencyName), index, 1)
end
function ConvertJewelCash.Protocol(index, packet, name)
    if packet ~= C.Packet then return false end
    local p = User.new(index)
    if name ~= 'JEWELCASH-' .. p:getName() then return false end
    local slot = GetBytePacket(name, -1)
    ClearPacket(name)
    if not C.Enabled or not integer(slot, 12, 203) or not ready(p) or busy[index] then return true end
    local inv = Inventory.new(index)
    if inv:isItem(slot) == 0 then return true end
    local itemIndex, level, selected = inv:getIndex(slot), inv:getLevel(slot), nil
    for _, e in ipairs(C.Entries or {}) do
        if valid(e) and itemIndex == GET_ITEM(e.Section, e.Index) and (e.Level == -1 or e.Level == level) then
            if selected then log('Itens configurados com niveis sobrepostos; conversao bloqueada.'); return true end
            selected = e
        end
    end
    if not selected then return true end
    local now = os.time()
    if last[index] and now - last[index] < (C.Cooldown or 2) then return true end
    last[index], busy[index] = now, true
    local ok, err = pcall(convert, index, slot, p, inv, selected)
    busy[index] = nil
    if not ok then
        log('Falha na conversao; confira pendencias no banco: ' .. tostring(err))
        SendMessage('Conversao indisponivel; procure a administracao.', index, 1)
    end
    return true
end
function ConvertJewelCash.Logout(index) busy[index], last[index] = nil, nil end
GameServerFunctions.GameServerProtocol(ConvertJewelCash.Protocol)
GameServerFunctions.PlayerLogout(ConvertJewelCash.Logout)
return ConvertJewelCash
