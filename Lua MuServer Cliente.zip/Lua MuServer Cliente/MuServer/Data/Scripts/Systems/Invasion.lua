--[[Invasão system By OgocX]]--

--Configurações Invasão
--Invasion Switch 0 = desativado 1 = ativado
local CONFIG_INVASION_SWITCH = 1

--Index é usado para identificar qual invasão está funcionando (Não utilize 0)
--Day of Week, Day, Hour, Minute
--Day of Week: 0 a 6: Domingo, segunda, terça, quarta, quinta, sexta, sabado
--Day of Week: -1 = Day
--Day = -1 = Horas e minutos.
--Exemplo: rodará todos os dias as 20h15min
--Exemplo 02: rodará todo dia 05 ás 15h00min
--Exemplo 03: rodará todo sábado as 15h00min
--Exemplo 03: rodará todos os dias as 15h00min
local CONFIG_INVASION_DATE = {

    --INVASÃO
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 00, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 01, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 02, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 03, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 04, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 05, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 06, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 07, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 08, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 09, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 09, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 10, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 11, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 12, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 13, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 14, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 15, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 16, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 18, _notification = 47, _minute = 48},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 17, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 18, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 19, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 20, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 21, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 22, _notification = 28, _minute = 30},
    {_index = 1, _dayofweek = -1, _day = -1, _hour = 23, _notification = 28, _minute = 30},

    --BOSS
    {_index = 2, _dayofweek = -1, _day = -1, _hour = 00, _notification = 00, _minute = 01},
    {_index = 2, _dayofweek = -1, _day = -1, _hour = 04, _notification = 00, _minute = 01},
    {_index = 2, _dayofweek = -1, _day = -1, _hour = 08, _notification = 00, _minute = 01},
    {_index = 2, _dayofweek = -1, _day = -1, _hour = 09, _notification = 00, _minute = 01},
    {_index = 2, _dayofweek = -1, _day = -1, _hour = 12, _notification = 00, _minute = 01},
    {_index = 2, _dayofweek = -1, _day = -1, _hour = 16, _notification = 00, _minute = 01},
    {_index = 2, _dayofweek = -1, _day = -1, _hour = 18, _notification = 00, _minute = 01},
    {_index = 2, _dayofweek = -1, _day = -1, _hour = 18, _notification = 00, _minute = 01},
    {_index = 2, _dayofweek = -1, _day = -1, _hour = 20, _notification = 00, _minute = 01},

    --INVASÃO HALLOWEEN
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 00, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 01, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 02, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 03, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 04, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 05, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 06, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 07, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 08, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 09, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 10, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 11, _notification = 28, _minute = 30},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 12, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 13, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 14, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 15, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 16, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 17, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 18, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 19, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 20, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 21, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 22, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 23, _notification = 48, _minute = 50},
    {_index = 3, _dayofweek = -1, _day = -1, _hour = 19, _notification = 49, _minute = 50},

    --DRAGAO DOURADO
    {_index = 4, _dayofweek = -1, _day = -1, _hour = 08, _notification = 14, _minute = 15},
    {_index = 4, _dayofweek = -1, _day = -1, _hour = 13, _notification = 14, _minute = 15},
    {_index = 4, _dayofweek = -1, _day = -1, _hour = 16, _notification = 14, _minute = 15},
    {_index = 4, _dayofweek = -1, _day = -1, _hour = 20, _notification = 14, _minute = 15},
}

--Index, nome, duração em minutos, anúncios de monstros vivos e mortes.
local CONFIG_INVASION_SYSTEM = {
    {_index = 1, _name = "Erohim em [Blood Arena]", _duration = 15, _announce_global = 1, _announce_death = 1},
    {_index = 2, _name = "Death Angel em [Blood Arena]", _duration = 15, _announce_global = 1, _announce_death = 1},
    {_index = 3, _name = "Halloween 2026 em [Mapa Halloween]", _duration = 15, _announce_global = 1, _announce_death = 1},
    {_index = 4, _name = "Dragão Dourado em [Lorencia]", _duration = 15, _announce_global = 1, _announce_death = 1},
}

--Index da invasão, classe do monstro, mapa e quantidade.
local INVASION_MONSTER_CREATE = {
    {_index = 1, _class = 295, _map = 84, _count = 30},
    {_index = 2, _class = 144, _map = 84, _count = 4},
    {_index = 3, _class = 410, _map = 86, _count = 30},
    {_index = 4, _class = 501, _map = 0, _count = 5},
}

--Recompensas por invasão e classe.
local MONSTER_DROP_CLASS = {
    {_index = 1, _class = 295, _section = 14, _item_index = 34, _level = 0, _luck = 0, _skill = 0, _opt = 0, _exc = 0, _count = 1},
    {_index = 2, _class = 144, _section = 14, _item_index = 124, _level = 0, _luck = 0, _skill = 0, _opt = 0, _exc = 0, _count = 1},
    {_index = 3, _class = 410, _section = 14, _item_index = 45, _level = 0, _luck = 0, _skill = 0, _opt = 0, _exc = 0, _count = 1},
}

local INVASION_MESSAGES = { }
INVASION_MESSAGES["Por"] = {
[1] = "A Invasão: %s, começou!",
[2] = "A Invasão: %s acabou!!!",
[3] = "%s matou um %s",
[4] = "Restam %d monstros vivos!",
}
INVASION_MESSAGES["Eng"] = {
[1] = "A Invasão: %s, começou!",
[2] = "A Invasão: %s acabou!!!",
[3] = "%s matou um %s",
[4] = "Restam %d monstros vivos!",
}
INVASION_MESSAGES["Spn"] = {
[1] = "A Invasão: %s, começou!",
[2] = "A Invasão: %s acabou!!!",
[3] = "%s matou um %s",
[4] = "Restam %d monstros vivos!",
}

--Não mexer aqui configurações do sistema
InvasionSystem = {}
INVASION_MONSTERS = {}
INVASION_SYSTEM = {}
INVASION_ITEMS_RAND = {}

local TimerStartInvasion = 0

function InvasionSystem.Init()
	if CONFIG_INVASION_SWITCH == 0
	then
		return
	end
	
	GameServerFunctions.MonsterDie(InvasionSystem.MonsterDie)
	GameServerFunctions.MonsterDieGiveItem(InvasionSystem.MonsterDieGiveItem)

	Timer.Interval(1, InvasionSystem.Running)
	
	for i in ipairs(CONFIG_INVASION_DATE) do
		if CONFIG_INVASION_DATE[i]._dayofweek ~= -1
		then
			Schedule.SetDayOfWeek(CONFIG_INVASION_DATE[i]._dayofweek, CONFIG_INVASION_DATE[i]._hour, CONFIG_INVASION_DATE[i]._notification, InvasionSystem.StartNotificacion, CONFIG_INVASION_DATE[i]._index)
			TimerStartInvasion = 1
		elseif CONFIG_INVASION_DATE[i]._day ~= -1
		then
			Schedule.SetDayAndHourAndMinute(CONFIG_INVASION_DATE[i]._day, CONFIG_INVASION_DATE[i]._hour, CONFIG_INVASION_DATE[i]._notification, InvasionSystem.StartNotificacion, CONFIG_INVASION_DATE[i]._index)
			TimerStartInvasion = 1
		else
			Schedule.SetHourAndMinute(CONFIG_INVASION_DATE[i]._hour, CONFIG_INVASION_DATE[i]._notification, InvasionSystem.StartNotificacion, CONFIG_INVASION_DATE[i]._index)
			TimerStartInvasion = 1
		end
	end
	
	for i in ipairs(CONFIG_INVASION_DATE) do
		if CONFIG_INVASION_DATE[i]._dayofweek ~= -1
		then
			Schedule.SetDayOfWeek(CONFIG_INVASION_DATE[i]._dayofweek, CONFIG_INVASION_DATE[i]._hour, CONFIG_INVASION_DATE[i]._minute, InvasionSystem.Start, CONFIG_INVASION_DATE[i]._index)
		elseif CONFIG_INVASION_DATE[i]._day ~= -1
		then
			Schedule.SetDayAndHourAndMinute(CONFIG_INVASION_DATE[i]._day, CONFIG_INVASION_DATE[i]._hour, CONFIG_INVASION_DATE[i]._minute, InvasionSystem.Start, CONFIG_INVASION_DATE[i]._index)
		else
			Schedule.SetHourAndMinute(CONFIG_INVASION_DATE[i]._hour, CONFIG_INVASION_DATE[i]._minute, InvasionSystem.Start, CONFIG_INVASION_DATE[i]._index)
		end
	end
end

function InvasionSystem.StartNotificacion(index)
    for i in ipairs(CONFIG_INVASION_SYSTEM) do
	    if CONFIG_INVASION_SYSTEM[i]._index == index
		then
            InvasionSystem.NameInvasion = CONFIG_INVASION_SYSTEM[i]._name
			InvasionSystem.TimerStart()
			Timer.Repeater(60, TimerStartInvasion, InvasionSystem.TimerStart)
		end
	end 
end

function InvasionSystem.TimerStart()
    if TimerStartInvasion > 0 
    then
        SendMessageGlobal(string.format("A Invasão: %s iniciará em %d minuto(s)", InvasionSystem.NameInvasion, TimerStartInvasion),0)
		TimerStartInvasion = TimerStartInvasion - 1
    end
end

function InvasionSystem.Start(index)
	if CONFIG_INVASION_SWITCH == 0
	then
		return
	end

	-- Horarios duplicados ou sobrepostos nao podem criar outra onda ativa.
	if INVASION_SYSTEM[index] then
		LogAdd(string.format("[Invasion] Invasao %s ja ativa; inicio ignorado.", tostring(index)))
		return
	end
	-- Se houve uma tentativa anterior de limpeza, conclua antes de criar outra onda.
	if InvasionSystem.ClearByMonster(index) == false then
		LogAdd(string.format("[Invasion] Limpeza pendente da invasao %s; inicio adiado.", tostring(index)))
		return
	end
	
	for i in ipairs(CONFIG_INVASION_SYSTEM) do
		if CONFIG_INVASION_SYSTEM[i]._index == index
		then
			Message.SendMessageGlobalMultLangArgs(INVASION_MESSAGES, 1, 0, CONFIG_INVASION_SYSTEM[i]._name)
			
			for n in ipairs(INVASION_MONSTER_CREATE) do
				if INVASION_MONSTER_CREATE[n]._index == index
				then
					InvasionSystem.CreateMonster(index, INVASION_MONSTER_CREATE[n]._class, INVASION_MONSTER_CREATE[n]._map, INVASION_MONSTER_CREATE[n]._count)
				end
			end
			
			INVASION_SYSTEM[index] = { _index = index, 
										_end = CONFIG_INVASION_SYSTEM[i]._duration * 60,
										_state = true,
										_running = true, 
										_Name = CONFIG_INVASION_SYSTEM[i]._name,
										_Announce_Death = CONFIG_INVASION_SYSTEM[i]._announce_death,
										_Announce_Global = CONFIG_INVASION_SYSTEM[i]._announce_global}
		end
	end
end

function InvasionSystem.Running()
	if CONFIG_INVASION_SWITCH == 0
	then
		return
	end
	
	for key in pairs(INVASION_SYSTEM) do
		if INVASION_SYSTEM[key]._running == true
		then
			if INVASION_SYSTEM[key]._end > 0 then
				INVASION_SYSTEM[key]._end = INVASION_SYSTEM[key]._end - 1
			end
			if INVASION_SYSTEM[key]._end <= 0 then
				InvasionSystem.InvasionEnd(key)
			end
		end
	end
end

function InvasionSystem.CreateMonster(invasion, class, map, count)
	if CONFIG_INVASION_SWITCH == 0
	then
		return
	end
	
	for i = 1, count do
		local index = AddMonster(map)
		
		if index == -1
		then
			LogAdd(string.format("[Invasion] Problema ao criar o monstro :%d", class))
			return
		end
		
		local monster = User.new(index)
		
		SetPositionMonster(index, map)
		SetMonster(index, class)
		
		monster:setRegenTime(0)
		
		LogAdd(string.format("[Invasion] Class:%d Map:%d CoordX:%d CoordY:%d",class, monster:getMapNumber(), monster:getX(), monster:getY()))
		
		INVASION_MONSTERS[index] = {_index = index, _Invasion = invasion, _Class = class, _Map = map}
	end
end

-- Apenas apaga o objeto que ainda corresponde ao monstro registrado.
-- Retorna false quando a exclusao falha, permitindo nova tentativa no timer.
local function RemoveTrackedMonster(entry)
	local index = entry._index
	if index == -1 or index == nil then return true end
	local ok, monster = pcall(User.new, index)
	if not ok or not monster then return false end
	local valid, connected, kind, class, map = pcall(function()
		return monster:getConnected(), monster:getType(), monster:getClass(), monster:getMapNumber()
	end)
	if not valid then return false end
	if connected == 0 then return true end
	if (kind ~= 2 and kind ~= 3) or class ~= entry._Class or (entry._Map ~= nil and map ~= entry._Map) then
		-- O indice foi reutilizado: nunca exclua outro objeto.
		LogAdd(string.format("[Invasion] Indice %s nao pertence mais a invasao; preservado.", tostring(index)))
		return true
	end
	local deleted = pcall(gObjDel, index)
	if not deleted then return false end
	local checked, after = pcall(function() return User.new(index):getConnected() end)
	return checked and after == 0
end

function InvasionSystem.InvasionEnd(key, expectedRun)
	local current = INVASION_SYSTEM[key]
	-- Um timer de uma onda antiga nao deve encerrar uma onda nova.
	if not current or (expectedRun and current ~= expectedRun) then return end
	current._ending = true
	if not InvasionSystem.ClearInvasionBy(key) then
		LogAdd(string.format("[Invasion] Falha ao remover monstros da invasao %s; nova tentativa no timer.", tostring(key)))
		current._end = 0
		return
	end
	Message.SendMessageGlobalMultLangArgs(INVASION_MESSAGES, 2, 0, current._Name)
	InvasionSystem.ClearSystemByInvasion(key)
end

function InvasionSystem.ClearInvasionBy(index)
	if CONFIG_INVASION_SWITCH == 0 then return false end
	return InvasionSystem.ClearByMonster(index)
end

function InvasionSystem.ClearByMonster(index)
	if CONFIG_INVASION_SWITCH == 0 then return false end
	local entries = {}
	for key, entry in pairs(INVASION_MONSTERS) do
		if entry._Invasion == index then entries[#entries + 1] = {key, entry} end
	end
	local complete = true
	for _, pair in ipairs(entries) do
		local key, entry = pair[1], pair[2]
		if INVASION_MONSTERS[key] == entry then
			if RemoveTrackedMonster(entry) then
				INVASION_MONSTERS[key] = nil
			else
				complete = false
			end
		end
	end
	return complete
end

function InvasionSystem.ClearSystemByInvasion(index)
	if CONFIG_INVASION_SWITCH == 0
	then
		return
	end
	
	for key in pairs(INVASION_SYSTEM) do
		if INVASION_SYSTEM[key]._index == index
		then
			INVASION_SYSTEM[key] = nil
		end
	end
end

function InvasionSystem.DelByMonster(invasion, index)
	if CONFIG_INVASION_SWITCH == 0
	then
		return
	end
	
	for key in pairs(INVASION_MONSTERS) do
		if INVASION_MONSTERS[key]._Invasion == invasion
		then
			if INVASION_MONSTERS[key]._index == index
			then
				if INVASION_MONSTERS[key]._index ~= -1
				then
					if RemoveTrackedMonster(INVASION_MONSTERS[key]) then
						INVASION_MONSTERS[key]._index = -1
					else
						LogAdd(string.format("[Invasion] Falha ao excluir monstro %s; mantido para nova tentativa.", tostring(index)))
					end
				end
			end
		end
	end
end

function InvasionSystem.GetByMonster(invasion, index)
	if CONFIG_INVASION_SWITCH == 0
	then
		return
	end
	
	if INVASION_MONSTERS[index] == nil
	then
		return -1
	end
	
	if INVASION_MONSTERS[index]._index == -1
	then
		return -1
	end
	
	if INVASION_MONSTERS[index]._Invasion == invasion
	then
		return INVASION_MONSTERS[index]._index
	end
	
	return -1
end

function InvasionSystem.GetCountMonsterByInvasion(invasion)
	local count = 0

	for key in pairs(INVASION_MONSTERS) do
		if INVASION_MONSTERS[key]._Invasion == invasion
		then
			if INVASION_MONSTERS[key]._index ~= -1
			then
				local monster = User.new(INVASION_MONSTERS[key]._index)
				
				if monster:getConnected() >= 2
				then
					count = count + 1
				end
			end
		end
	end
	
	return count
end

function InvasionSystem.InsertItens(item)
	InsertKey(INVASION_ITEMS_RAND, item)
end

function InvasionSystem.GetItemRand()
	if #INVASION_ITEMS_RAND > 0
	then
		return GetRand(1, #INVASION_ITEMS_RAND)
	end
	
	return -1
end

function InvasionSystem.DropItemByMonster(index, Player, Monster)
	if CONFIG_INVASION_SWITCH == 0
	then
		return
	end
	
	INVASION_ITEMS_RAND = {}
	
	local player = User.new(Player)
	local monster = User.new(Monster)
	
	for i in ipairs(MONSTER_DROP_CLASS) do
		if MONSTER_DROP_CLASS[i]._index == index and MONSTER_DROP_CLASS[i]._class == monster:getClass()
		then
			InvasionSystem.InsertItens(MONSTER_DROP_CLASS[i])
		end
	end
	
	local key_rand = InvasionSystem.GetItemRand()
	
	if key_rand == -1
	then
		LogAdd("[Invasion] Existe uma má configuração no sistema de dropar item")
		return
	end
	
	local ItemDrop = INVASION_ITEMS_RAND[key_rand]
	
	for i = 1, ItemDrop._count do
		ItemSerialCreate(Player, player:getMapNumber(), player:getX(), player:getY(), GET_ITEM(ItemDrop._section, ItemDrop._item_index), ItemDrop._level, 255, ItemDrop._luck, ItemDrop._skill, ItemDrop._opt, ItemDrop._exc)
	end
end

function InvasionSystem.MonsterDie(Player, Monster)
	if CONFIG_INVASION_SWITCH == 0
	then
		return
	end
	
	local player = User.new(Player)
	local monster = User.new(Monster)
	
	for key in pairs(INVASION_SYSTEM) do
		if INVASION_SYSTEM[key]._running == true and not INVASION_SYSTEM[key]._ending
		then
			if InvasionSystem.GetByMonster(INVASION_SYSTEM[key]._index, Monster) == Monster
			then
				--Monstrar no global que o player X matou o monstro X
				if INVASION_SYSTEM[key]._Announce_Death == 1
				then
					Message.SendMessageGlobalMultLangArgs(INVASION_MESSAGES, 3, 0, player:getName(), monster:getName())
				end
				
				--Dizer quantos monstros restam
				if INVASION_SYSTEM[key]._Announce_Global == 1
				then
					local MonsterCount = math.floor(InvasionSystem.GetCountMonsterByInvasion(INVASION_SYSTEM[key]._index) - 1)
					if MonsterCount > 0
					then
						Message.SendMessageGlobalMultLangArgs(INVASION_MESSAGES, 4, 0, MonsterCount)
					else
						--Finalizar a invasão mataram todos monstros
						Timer.TimeOut(5, InvasionSystem.InvasionEnd, key, INVASION_SYSTEM[key])
					end
				end
			end
		end
	end
end

function InvasionSystem.MonsterDieGiveItem(Player, Monster)
	if CONFIG_INVASION_SWITCH == 0
	then
		return
	end
	
	for key in pairs(INVASION_SYSTEM) do
		if INVASION_SYSTEM[key]._running == true and not INVASION_SYSTEM[key]._ending
		then
			if InvasionSystem.GetByMonster(INVASION_SYSTEM[key]._index, Monster) == Monster
			then
				--Sistema onde vai gerar 1 item aleatório
				InvasionSystem.DropItemByMonster(INVASION_SYSTEM[key]._index, Player, Monster)
				
				--Remover o monstro do sistema
				InvasionSystem.DelByMonster(INVASION_SYSTEM[key]._index, Monster)
				return 1
			end
		end
	end
	
	return
end

-- Agenda compartilhada com o painel; usa as mesmas configuracoes do scheduler.
function InvasionSystem.GetNotificationSchedule()
	if CONFIG_INVASION_SWITCH == 0 then return {}, {} end
	return CONFIG_INVASION_SYSTEM, CONFIG_INVASION_DATE
end

InvasionSystem.Init()

return InvasionSystem