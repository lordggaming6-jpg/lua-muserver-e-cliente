-- Le o estado do Systems/Invasion.lua distribuido em Scripts.zip.
-- Nao cria monstros nem modifica horarios, mortes ou recompensas.
InvasionNotifications = {}
local lastRequest, lastMove = {}, {}
local MAX_INVASIONS, MAX_GROUPS = 8, 16

local function log(message)
    if InvasionNotifications_Config.Debug then
        LogAdd("[INVASOES] " .. message)
    end
end

function InvasionNotifications.CheckSetup()
    log(string.format("Modulo carregado. Packet %d; protocolo INVN2; ativo=%s.",
        InvasionNotifications_Config.Packet, tostring(InvasionNotifications_Config.Enabled)))
    if InvasionSystem and InvasionSystem.GetNotificationSchedule then
        local definitions, schedules = InvasionSystem.GetNotificationSchedule()
        log(string.format("Agenda integrada: %d invasoes, %d horarios.", #definitions, #schedules))
    else
        log("Agenda nao integrada: confira Systems/Invasion.lua (GetNotificationSchedule).")
    end
end

local function bounded(value, maximum)
    return math.max(0, math.min(maximum, math.floor(tonumber(value) or 0)))
end

local function writeText(packet, value, maximum)
    local text = tostring(value or ""):sub(1, maximum)
    SetBytePacket(packet, #text)
    if #text > 0 then SetCharPacketLength(packet, text, #text) end
end

-- Mesmo calendario local do Schedule.lua: diario, dia da semana ou dia do mes.
function InvasionNotifications.NextStart(schedule, now)
    local current = os.date("*t", now)
    local days = schedule._dayofweek ~= -1 and 7 or (schedule._day ~= -1 and 62 or 1)
    for offset = 0, days do
        local day = os.date("*t", os.time({year = current.year, month = current.month,
            day = current.day + offset, hour = 12}))
        local matches = schedule._dayofweek ~= -1 and day.wday - 1 == schedule._dayofweek
            or schedule._dayofweek == -1 and (schedule._day == -1 or day.day == schedule._day)
        if matches then
            local candidate = os.time({year = day.year, month = day.month, day = day.day,
                hour = schedule._hour, min = schedule._minute, sec = 0})
            if candidate >= now then return candidate - now end
        end
    end
end

function InvasionNotifications.Snapshot()
    local result, ids, upcoming, names = {}, {}, {}, {}
    local definitions, schedules = {}, {}
    if InvasionSystem and InvasionSystem.GetNotificationSchedule then
        definitions, schedules = InvasionSystem.GetNotificationSchedule()
    end
    local now = os.time()
    for _, definition in ipairs(definitions) do names[definition._index] = definition._name end
    for _, schedule in ipairs(schedules) do
        if names[schedule._index] then
            local seconds = InvasionNotifications.NextStart(schedule, now)
            local previous = upcoming[schedule._index]
            if seconds and (not previous or seconds < previous) then
                upcoming[schedule._index] = seconds
            end
        end
    end
    local active, activeCount = {}, 0
    for id, invasion in pairs(INVASION_SYSTEM or {}) do
        if invasion._running == true and (invasion._end or 0) > 0 then
            ids[#ids + 1] = id
            active[id], activeCount = true, activeCount + 1
        end
    end
    for id in pairs(upcoming) do
        if not active[id] then ids[#ids + 1] = id end
    end
    table.sort(ids, function(a, b)
        if active[a] ~= active[b] then return active[a] == true end
        if not active[a] and upcoming[a] ~= upcoming[b] then return upcoming[a] < upcoming[b] end
        return a < b
    end)
    for _, id in ipairs(ids) do
        if #result >= MAX_INVASIONS then break end
        if not active[id] then
            result[#result + 1] = {Id = id, Name = names[id], Active = false,
                Seconds = upcoming[id], Monsters = {}, MoreGroups = false}
        else
            local invasion = INVASION_SYSTEM[id]
            local groups, classes = {}, {}
            for _, entry in pairs(INVASION_MONSTERS or {}) do
                if entry._Invasion == id then
                    local class = entry._Class
                    if not groups[class] then
                        groups[class] = {Class = class, Alive = 0, Total = 0,
                            Name = InvasionNotifications_Config.MonsterNames[class]}
                        classes[#classes + 1] = class
                    end
                    local group = groups[class]
                    group.Total = group.Total + 1
                    -- O sistema original preserva entradas mortas com _index = -1.
                    if entry._index ~= -1 then
                        local monster = User.new(entry._index)
                        if monster:getConnected() >= 2 then
                            group.Alive = group.Alive + 1
                            group.Name = group.Name or monster:getName()
                        end
                    end
                end
            end
            table.sort(classes)
            local list = {}
            for _, class in ipairs(classes) do
                if #list >= MAX_GROUPS then break end
                local group = groups[class]
                group.Name = group.Name or string.format("Monstro #%d", class)
                list[#list + 1] = group
            end
            result[#result + 1] = {Id = id, Name = invasion._Name, Active = true,
                Seconds = invasion._end, Monsters = list, MoreGroups = #classes > #list}
        end
    end
    return result, #ids > #result, activeCount
end

function InvasionNotifications.Send(aIndex, name, version)
    version = version or 2 -- chamadas antigas continuam usando INVN2
    local packet = "INVN" .. version .. "_DATA-" .. name
    local invasions, more, activeCount = InvasionNotifications.Snapshot()
    if version == 3 then
        -- Os pacotes Lua da source possuem buffer de 5000 bytes. Reserve espaco
        -- para todos os cabecalhos antes de incluir os grupos de monstros.
        local remaining = 4999 - 4
        for _, event in ipairs(invasions) do
            remaining = remaining - 12 - #tostring(event.Name or ""):sub(1, 40)
        end
        for _, event in ipairs(invasions) do
            local groups = {}
            for _, monster in ipairs(event.Monsters) do
                local size = 9 + #tostring(monster.Name or ""):sub(1, 32)
                if remaining >= size then
                    groups[#groups + 1] = monster
                    remaining = remaining - size
                else
                    event.MoreGroups = true
                end
            end
            event.Monsters = groups
        end
    end
    CreatePacket(packet, InvasionNotifications_Config.Packet)
    SetBytePacket(packet, #invasions)
    SetBytePacket(packet, more and 1 or 0)
    SetWordPacket(packet, bounded(activeCount, 65535))
    for _, invasion in ipairs(invasions) do
        SetDwordPacket(packet, bounded(invasion.Id, 4294967295))
        writeText(packet, invasion.Name, 40)
        SetDwordPacket(packet, bounded(invasion.Seconds, 4294967295))
        SetBytePacket(packet, invasion.Active and 1 or 0)
        SetBytePacket(packet, #invasion.Monsters)
        SetBytePacket(packet, invasion.MoreGroups and 1 or 0)
        for _, monster in ipairs(invasion.Monsters) do
            if version == 3 then SetDwordPacket(packet, bounded(monster.Class, 4294967295)) end
            writeText(packet, monster.Name, 32)
            SetWordPacket(packet, bounded(monster.Alive, 65535))
            SetWordPacket(packet, bounded(monster.Total, 65535))
        end
    end
    SendPacket(packet, aIndex)
    ClearPacket(packet)
    return #invasions, activeCount
end

-- O destino e derivado exclusivamente de monstro ativo no servidor.
function InvasionNotifications.Participate(aIndex, player, invasionId, class)
    local invasion = (INVASION_SYSTEM or {})[invasionId]
    if not invasion or invasion._running ~= true or (invasion._end or 0) <= 0 then
        SendMessage("Esta invasao nao esta ativa.", aIndex, 1); return
    end
    if player:getLive() ~= 1 or player:getState() ~= 2 or player:getDieRegen() ~= 0
        or player:getTeleport() ~= 0 or player:getInterfaceUse() ~= 0
        or player:getInterfaceType() ~= 0 or player:getShopOpen() ~= 0
        or (player.getUsingTradeX and player:getUsingTradeX() ~= 0) then
        SendMessage("Feche as janelas e tente novamente quando estiver disponivel.", aIndex, 1); return
    end
    for _, entry in pairs(INVASION_MONSTERS or {}) do
        if entry._Invasion == invasionId and entry._Class == class and type(entry._index) == "number" and entry._index >= 0 then
            local monster = User.new(entry._index)
            if monster:getConnected() >= 2 and monster:getType() == 2
                and monster:getLive() == 1 and monster:getClass() == class then
                local map, x, y = monster:getMapNumber(), monster:getX(), monster:getY()
                if type(map) == "number" and map >= 0 and map < 100 and type(x) == "number" and type(y) == "number"
                    and x >= 0 and x <= 255 and y >= 0 and y <= 255 then
                    -- Evita o tile do monstro e posicoes bloqueadas; nao inventa coordenadas do cliente.
                    for radius = 1, 4 do
                        for dx = -radius, radius do
                            for dy = -radius, radius do
                                if math.max(math.abs(dx), math.abs(dy)) == radius then
                                    local tx, ty = x + dx, y + dy
                                    if tx >= 0 and tx <= 255 and ty >= 0 and ty <= 255
                                        and GetMapAttr(map, tx, ty, 14) == 0 then
                                        Teleport(aIndex, map, tx, ty)
                                        return
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
    SendMessage("Nenhum monstro vivo ou destino disponivel nesta invasao.", aIndex, 1)
end

function InvasionNotifications.Protocol(aIndex, packet, packetName)
    local config = InvasionNotifications_Config
    if packet ~= config.Packet then return false end
    local player = User.new(aIndex)
    local name = player:getName()
    local oldRequest = packetName == "INVN2_GET-" .. name
    local newRequest = packetName == "INVN3_GET-" .. name
    local moveRequest = packetName == "INVN3_MOVE-" .. name
    if not oldRequest and not newRequest and not moveRequest then return false end
    local invasionId, class
    if moveRequest then
        invasionId = GetDwordPacket(packetName, -1)
        class = GetDwordPacket(packetName, -1)
    end
    ClearPacket(packetName)
    if not config.Enabled or player:getConnected() < 3 or player:getType() ~= 1 then return true end
    local now = os.time()
    if moveRequest then
        if lastMove[aIndex] and now - lastMove[aIndex] < 2 then return true end
        lastMove[aIndex] = now
        InvasionNotifications.Participate(aIndex, player, invasionId, class)
        return true
    end
    if lastRequest[aIndex] and now - lastRequest[aIndex] < config.RequestCooldown then return true end
    local firstRequest = lastRequest[aIndex] == nil
    lastRequest[aIndex] = now
    local count, activeCount = InvasionNotifications.Send(aIndex, name, newRequest and 3 or 2)
    if firstRequest then
        log(string.format("Pedido INVN recebido; resposta enviada: %d invasoes, %d ativas.", count, activeCount))
    end
    return true
end

function InvasionNotifications.Logout(aIndex)
    lastRequest[aIndex], lastMove[aIndex] = nil, nil
end

GameServerFunctions.GameServerProtocol(InvasionNotifications.Protocol)
GameServerFunctions.PlayerLogout(InvasionNotifications.Logout)
Timer.TimeOut(2, InvasionNotifications.CheckSetup)
return InvasionNotifications
