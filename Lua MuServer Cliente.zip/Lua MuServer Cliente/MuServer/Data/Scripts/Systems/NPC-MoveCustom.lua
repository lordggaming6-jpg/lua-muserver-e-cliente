-- NPC-MoveCustom independente das invasoes. O servidor decide modo, item e destino.
NPCMoveCustom = {}
local C = NPCMoveCustomConfig
local last = {}

local function playerReady(p)
    return p:getConnected() >= 3 and p:getType() == 1 and p:getLive() == 1
        and p:getTeleport() == 0 and p:getDieRegen() == 0
        and p:getInterfaceUse() == 0 and p:getInterfaceType() == 0
        and p:getShopOpen() == 0
        and (not p.getUsingTradeX or p:getUsingTradeX() == 0)
end

local function matches(inv, slot, item)
    return inv:isItem(slot) ~= 0 and inv:getIndex(slot) == GET_ITEM(item.Section, item.Index)
        and (item.Level == -1 or inv:getLevel(slot) == item.Level)
end

local function tryMove(index, slot, entry)
    local p = User.new(index)
    if type(entry.Item) ~= "table" or type(entry.Item.Required) ~= "boolean" then
        SendMessage(C.UnavailableMessage, index, 1); return
    end
    if not playerReady(p) then SendMessage("Feche as janelas e tente novamente.", index, 1); return end
    if not MoveSystem or type(MoveSystem.CheckMove) ~= "function" or MOVES_CUSTOMS_SWITCH == 0
        or MoveSystem.NPCMoveCustomHook ~= true or not SerializeMoves or not SerializeMoves[entry.Command] then
        SendMessage(C.UnavailableMessage, index, 1); return
    end
    local inv = Inventory.new(index)
    if entry.Item.Required then
        if slot then
            if not matches(inv, slot, entry.Item) then return end
        else
            for i = 12, 203 do
                if matches(inv, i, entry.Item) then slot = i; break end
            end
            if not slot then SendMessage(C.MissingMessage, index, 1); return end
        end
    end
    local now = os.time()
    if last[index] and now - last[index] < 2 then return end
    last[index] = now
    MoveSystem.CheckMove(index, entry.Command, entry.Command, function()
        if not entry.Item.Required then return true end
        -- Revalida o slot depois das regras de movimento; apaga exatamente o item escolhido.
        if not matches(inv, slot, entry.Item) then SendMessage(C.MissingMessage, index, 1); return false end
        local itemIndex = inv:getIndex(slot)
        if GetStackItem(itemIndex) > 0 and inv:getDurability(slot) > 1 then
            inv:setDurability(slot, inv:getDurability(slot) - 1)
            inv:convertItem(slot)
            ItemListSend(index)
        else
            InventoryDeleteItem(index, slot)
            SendInventoryDeleteItem(index, slot)
        end
        return true
    end)
end

-- Configuracoes antigas com uma unica entrada continuam funcionando.
local function entries()
    return C.Entries or {C}
end

local function ambiguous(index)
    LogAdd("[NPC-MoveCustom] Configuracoes sobrepostas; revise NPCs ou itens.")
    SendMessage(C.UnavailableMessage, index, 1)
end

function NPCMoveCustom.NpcTalk(npcIndex, playerIndex)
    if not C.Enabled then return 0 end
    local npc = User.new(npcIndex)
    local selected
    for _, entry in ipairs(entries()) do
        if entry.Mode == "NPC" and npc:getClass() == entry.NpcClass
            and (entry.NpcMap == -1 or npc:getMapNumber() == entry.NpcMap) then
            if selected then ambiguous(playerIndex); return 1 end
            selected = entry
        end
    end
    if not selected then return 0 end
    tryMove(playerIndex, nil, selected)
    return 1
end

function NPCMoveCustom.Protocol(index, packet, name)
    if packet ~= C.Packet then return false end
    local player = User.new(index)
    if name ~= "NPCMOVE-" .. player:getName() then return false end
    local slot = GetBytePacket(name, -1)
    ClearPacket(name)
    if C.Enabled and slot >= 12 and slot <= 203 and playerReady(player) then
        local inv, selected = Inventory.new(index), nil
        for _, entry in ipairs(entries()) do
            if entry.Mode == "ITEM" and entry.Item and entry.Item.Required
                and matches(inv, slot, entry.Item) then
                if selected then ambiguous(index); return true end
                selected = entry
            end
        end
        if selected then tryMove(index, slot, selected) end
    end
    return true
end

function NPCMoveCustom.Logout(index) last[index] = nil end
GameServerFunctions.NpcTalk(NPCMoveCustom.NpcTalk)
GameServerFunctions.GameServerProtocol(NPCMoveCustom.Protocol)
GameServerFunctions.PlayerLogout(NPCMoveCustom.Logout)
return NPCMoveCustom
