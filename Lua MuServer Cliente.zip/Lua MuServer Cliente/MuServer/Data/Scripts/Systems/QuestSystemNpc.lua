-- Quest V2. Este arquivo substitui o antigo sistema por NPC.
QuestSystemNpc = {}
local Q = QuestSystemNpc
local C = QuestWindowConfig
local sessions, retired, requestTimes = {}, {}, {}
local configs = {}
local currencies = QUEST_SYSTEM_NPC_CURRENCIES or {}
local currencyRequirements = QUEST_SYSTEM_NPC_REQUIREMENTS_CURRENCIES or {}
local busy
local fields = {'QuestID','Run','State','OnlineSeconds','Kills'}
for i=1,9 do fields[#fields+1]='Kill'..i end
local function log(s) LogAddC(2,'[QuestV2] '..s) end
local function quote(s) return "'"..tostring(s):gsub("'","''").."'" end
local function int(n) return type(n)=='number' and n==math.floor(n) and n>=0 and n<=2147483647 end
local function tick() return GetTick()%4294967296 end
local function elapsed(now,previous) return (now-previous)%4294967296 end
local function where(s,id) return 'AccountID='..quote(s.Account)..' AND Name='..quote(s.Name)..' AND QuestID='..id end
local function transaction(sql,select)
    return 'SET NOCOUNT ON; SET XACT_ABORT ON; BEGIN TRY BEGIN TRANSACTION; '..sql..
        ' COMMIT; '..(select or '')..' END TRY BEGIN CATCH IF @@TRANCOUNT>0 ROLLBACK; '..
        "RAISERROR('QuestV2: transacao falhou',16,1); END CATCH;"
end
local function query(sql,columns)
    local d=DataBase.getDb()
    if d:exec(sql)==0 then d:clear(); log('Falha SQL; operacao bloqueada. Confira QuestV2.sql em MuOnline.'); return nil end
    local rows={}
    if columns then
        while d:fetch()~=SQL_NO_DATA do
            local row={}
            for _,key in ipairs(columns) do row[key]=d:getInt(key) end
            rows[#rows+1]=row
        end
    end
    d:clear()
    return rows
end
local function historyUpdate(s,r)
    local kills=''
    for i=1,9 do kills=kills..'Kill'..i..'=p.Kill'..i..',' end
    return 'UPDATE h SET '..kills..'State=p.State,OnlineSeconds=p.OnlineSeconds,Kills=p.Kills,'..
        'UpdatedAt=GETDATE() FROM dbo.QuestHistoryV2 h JOIN dbo.QuestProgressV2 p ON '..
        'h.AccountID=p.AccountID AND h.Name=p.Name AND h.QuestID=p.QuestID AND h.Run=p.Run '..
        'WHERE p.AccountID='..quote(s.Account)..' AND p.Name='..quote(s.Name)..' AND p.QuestID='..r.QuestID..'; '
end
local function describe(value)
    if type(value)~='table' then return tostring(value) end
    local keys={}; for key in pairs(value) do keys[#keys+1]=key end
    table.sort(keys,function(a,b) return tostring(a)<tostring(b) end)
    local out={}; for _,key in ipairs(keys) do out[#out+1]=tostring(key)..'='..describe(value[key]) end
    return '{'..table.concat(out,';')..'}'
end
-- SQL names come only from validated server configuration, never from packets.
local function identifier(name)
    assert(type(name)=='string' and #name<=128 and name:match('^[A-Za-z_][A-Za-z0-9_]*$'),'Identificador SQL de moeda invalido')
    return '['..name..']'
end
local function currencyTable(v)
    return (v.Database and (identifier(v.Database)..'.') or '')..identifier(v.Schema or 'dbo')..'.'..identifier(v.Table)
end
local function currencyOwner(v,s) return v.Owner=='Account' and s.Account or s.Name end
local function currencyWhere(v,s) return identifier(v.KeyColumn)..'='..quote(currencyOwner(v,s)) end
local function currencyOperations(id)
    local result,byID={},{}
    local function get(key)
        if not byID[key] then
            byID[key]={ID=key,Required=0,Debit=0,Credit=0}; result[#result+1]=byID[key]
        end
        return byID[key]
    end
    for _,v in ipairs(currencyRequirements[id] or {}) do
        local op=get(v.Currency); op.Required=v.Amount; op.Debit=v.Remove and v.Amount or 0
    end
    for _,v in ipairs(QUEST_SYSTEM_NPC_REWARD_COINS[id] or {}) do
        if v.Currency then local op=get(v.Currency); op.Credit=op.Credit+v.CoinAmount end
    end
    -- A stable lock order reduces deadlocks across different quests.
    table.sort(result,function(a,b) return a.ID<b.ID end)
    return result
end
local function currencyReservation(s,r)
    local sql=''
    for i,op in ipairs(currencyOperations(r.QuestID)) do
        local v=currencies[op.ID]; local column=identifier(v.Column)
        local balance='@balance'..i; local count='@count'..i
        sql=sql..'DECLARE '..balance..' bigint,'..count..' bigint; SELECT '..count..'=COUNT_BIG(*),'..balance..
            '=MIN(CASE WHEN '..column..' BETWEEN 0 AND 2147483647 AND '..column..'=FLOOR('..column..') THEN CONVERT(bigint,'..column..') ELSE -1 END) FROM '..
            currencyTable(v)..' WITH(UPDLOCK,HOLDLOCK) WHERE '..currencyWhere(v,s)..'; '..
            'IF '..count..'<>1 OR '..balance..' IS NULL OR '..balance..'<'..op.Required..' OR '..balance..'-'..op.Debit..'+'..op.Credit..
            ">2147483647 RAISERROR('QuestV2: saldo de moeda indisponivel',16,1); "
        if op.Debit>0 or op.Credit>0 then
            sql=sql..'UPDATE '..currencyTable(v)..' SET '..column..'='..column..'-'..op.Debit..'+'..op.Credit..
                ' WHERE '..currencyWhere(v,s).."; IF @@ROWCOUNT<>1 RAISERROR('QuestV2: conta de moeda invalida',16,1); "
        end
        sql=sql..'INSERT dbo.QuestCurrencyV2(AccountID,Name,QuestID,Run,CurrencyID,TableName,ColumnName,KeyColumn,OwnerKey,RequiredAmount,Debit,Credit,BalanceBefore,BalanceAfter) VALUES('..
            quote(s.Account)..','..quote(s.Name)..','..r.QuestID..','..r.Run..','..quote(op.ID)..','..quote(currencyTable(v))..','..
            quote(v.Column)..','..quote(v.KeyColumn)..','..quote(currencyOwner(v,s))..','..op.Required..','..op.Debit..','..op.Credit..','..
            balance..','..balance..'-'..op.Debit..'+'..op.Credit..'); '
    end
    return sql
end
Q.Store = {}
function Q.Store.Balance(s,key)
    local v=currencies[key]; local column=identifier(v.Column)
    local rows=query('SELECT COUNT(*) AS Matches,MIN(CASE WHEN '..column..' BETWEEN 0 AND 2147483647 AND '..column..'=FLOOR('..column..
        ') THEN CONVERT(int,'..column..') ELSE -1 END) AS Balance FROM '..currencyTable(v)..' WHERE '..currencyWhere(v,s)..';',{'Matches','Balance'})
    if rows and rows[1] and rows[1].Matches==1 and int(rows[1].Balance) then return rows[1].Balance end
    return nil
end
function Q.Store.Load(s)
    return query('SELECT '..table.concat(fields,',')..' FROM dbo.QuestProgressV2 WHERE AccountID='..quote(s.Account)..' AND Name='..quote(s.Name),fields)
end
function Q.Store.Start(s,id,expected,repeatable)
    local key=where(s,id)
    local rules=describe({Quest=configs[id],Items=QUEST_SYSTEM_NPC_REQUIREMENTS_ITEMS[id],Monsters=QUEST_SYSTEM_NPC_REQUIREMENTS_MONSTER[id],
        Currencies=currencies,CurrencyRequirements=currencyRequirements[id],RewardItems=QUEST_SYSTEM_NPC_REWARD_ITEMS[id],RewardCoins=QUEST_SYSTEM_NPC_REWARD_COINS[id],RewardBuffs=QUEST_SYSTEM_NPC_REWARD_BUFF[id]})
    local sql='DECLARE @started int=0; '..
        'IF NOT EXISTS (SELECT 1 FROM dbo.QuestProgressV2 WITH(UPDLOCK,HOLDLOCK) WHERE AccountID='..quote(s.Account)..
        ' AND Name='..quote(s.Name)..' AND State IN(1,3)) BEGIN '..
        'IF NOT EXISTS(SELECT 1 FROM dbo.QuestProgressV2 WITH(UPDLOCK,HOLDLOCK) WHERE '..key..') '..
        'INSERT dbo.QuestProgressV2(AccountID,Name,QuestID) VALUES('..quote(s.Account)..','..quote(s.Name)..','..id..'); '..
        'UPDATE dbo.QuestProgressV2 SET Run=Run+1,State=1,OnlineSeconds=0,Kills=0,'
    for i=1,9 do sql=sql..'Kill'..i..'=0,' end
    sql=sql..'StartedAt=GETDATE(),UpdatedAt=GETDATE() WHERE '..key..' AND Run='..expected..
        ' AND State IN (0,4'..(repeatable and ',2' or '')..'); SET @started=@@ROWCOUNT; '..
        'IF @started=1 INSERT dbo.QuestHistoryV2(AccountID,Name,QuestID,Run,State,StartedAt,UpdatedAt,RuleSnapshot) '..
        'SELECT AccountID,Name,QuestID,Run,State,StartedAt,UpdatedAt,'..quote(rules)..' FROM dbo.QuestProgressV2 WHERE '..key..'; END;'
    local rows=query(transaction(sql,'SELECT '..table.concat(fields,',')..' FROM dbo.QuestProgressV2 WHERE '..key..' AND @started=1;'),fields)
    return rows and rows[1]
end
function Q.Store.Save(s,r)
    local values={'OnlineSeconds','Kills'}
    for i=1,9 do values[#values+1]='Kill'..i end
    local updates={}
    for _,key in ipairs(values) do updates[#updates+1]=key..'=CASE WHEN '..key..'<'..r[key]..' THEN '..r[key]..' ELSE '..key..' END' end
    local sql='DECLARE @ok int=0; UPDATE dbo.QuestProgressV2 SET '..table.concat(updates,',')..',UpdatedAt=GETDATE() WHERE '..
        where(s,r.QuestID)..' AND Run='..r.Run..' AND State=1; SET @ok=@@ROWCOUNT; '..historyUpdate(s,r)
    local rows=query(transaction(sql,'SELECT @ok AS Success;'),{'Success'})
    return rows and rows[1] and rows[1].Success==1
end
function Q.Store.Transition(s,r,target)
    local sql='DECLARE @ok int=0; UPDATE dbo.QuestProgressV2 SET State='..target..
        ',UpdatedAt=GETDATE() WHERE '..where(s,r.QuestID)..' AND Run='..r.Run..' AND State='..r.State..
        '; SET @ok=@@ROWCOUNT; '..(target==3 and ('IF @ok=1 BEGIN '..currencyReservation(s,r)..'END; ') or '')..historyUpdate(s,r)
    local rows=query(transaction(sql,'SELECT @ok AS Success;'),{'Success'})
    return rows and rows[1] and rows[1].Success==1
end
local rewardFields={'ID','State','ItemIndex','Level','Op1','Op2','Life','Exc','Ancient','JoH','SocketBonus',
    'Sock1','Sock2','Sock3','Sock4','Sock5','ItemTime'}
function Q.Store.Finish(s,r,items)
    local sql='DECLARE @ok int=0; IF EXISTS(SELECT 1 FROM dbo.QuestProgressV2 WITH(UPDLOCK,HOLDLOCK) WHERE '..
        where(s,r.QuestID)..' AND Run='..r.Run..' AND State=3) BEGIN '
    local ordinal=0
    for _,v in ipairs(items) do
        for n=1,v.Count do
            ordinal=ordinal+1
            sql=sql..'INSERT dbo.QuestRewardV2(AccountID,Name,QuestID,Run,Ordinal,ItemIndex,Level,Op1,Op2,Life,Exc,Ancient,JoH,SocketBonus,'..
                'Sock1,Sock2,Sock3,Sock4,Sock5,ItemTime) VALUES('..quote(s.Account)..','..quote(s.Name)..','..r.QuestID..','..r.Run..','..ordinal..','..
                table.concat({v.ItemIndex,v.Level,v.Op1,v.Op2,v.Life,v.Exc,v.Ancient,v.JoH,v.SocketBonus,
                    v.Sock1,v.Sock2,v.Sock3,v.Sock4,v.Sock5,v.ItemTime},',')..'); '
        end
    end
    sql=sql..'UPDATE dbo.QuestProgressV2 SET State=2,UpdatedAt=GETDATE() WHERE '..where(s,r.QuestID)..'; '..
        historyUpdate(s,r)..'SET @ok=1; END;'
    local rows=query(transaction(sql,'SELECT @ok AS Success;'),{'Success'})
    return rows and rows[1] and rows[1].Success==1
end
function Q.Store.Pending(s,id,run)
    return query('SELECT '..table.concat(rewardFields,',')..' FROM dbo.QuestRewardV2 WHERE '..where(s,id)..' AND Run='..run..' AND State<>2 ORDER BY ID',rewardFields)
end
function Q.Store.RewardState(s,id,from,to)
    local sql='DECLARE @ok int=0; UPDATE dbo.QuestRewardV2 SET State='..to..',UpdatedAt=GETDATE() WHERE ID='..id..
        ' AND AccountID='..quote(s.Account)..' AND Name='..quote(s.Name)..' AND State='..from..'; SET @ok=@@ROWCOUNT;'
    local rows=query(transaction(sql,'SELECT @ok AS Success;'),{'Success'})
    return rows and rows[1] and rows[1].Success==1
end
function Q.Deliver(p,s,r)
    local pending=Q.Store.Pending(s,r.QuestID,r.Run)
    if not pending then return 'Nao foi possivel consultar a entrega.' end
    local v=pending[1]
    if not v then return 'Recompensas retiradas.' end
    if v.State~=0 then return 'Entrega pendente de conferencia. Avise a administracao.' end
    if busy(p) then return 'Feche as outras interfaces antes de retirar.' end
    if InventoryCheckSpaceByItem(p:getIndex(),v.ItemIndex)~=1 then return 'Libere espaco e clique em Retirar premio nesta janela.' end
    if not Q.Store.RewardState(s,v.ID,0,1) then return 'Entrega nao confirmada. Atualize a janela.' end
    -- Native CreateItemInventory has no documented persistence acknowledgement.
    -- Reserve FIRST; never automatically repeat an uncertain delivery.
    local ok,err=pcall(CreateItemInventory,p:getIndex(),v.ItemIndex,v.Level,v.Op1,v.Op2,v.Life,v.Exc,v.Ancient,
        v.JoH,v.SocketBonus,v.Sock1,v.Sock2,v.Sock3,v.Sock4,v.Sock5,v.ItemTime)
    if not ok then
        Q.Store.RewardState(s,v.ID,1,3); log('Falha na entrega ID '..v.ID..': '..tostring(err))
        return 'Entrega pendente de conferencia. Avise a administracao.'
    end
    if not Q.Store.RewardState(s,v.ID,1,2) then return 'Entrega enviada; confirmacao pendente. Avise a administracao.' end
    return #pending>1 and 'Item entregue. Clique para retirar o proximo premio.' or 'Recompensa entregue no inventario!'
end
local function record(id)
    local r={QuestID=id,Run=0,State=0,OnlineSeconds=0,Kills=0}
    for i=1,9 do r['Kill'..i]=0 end
    return r
end
local function same(p,s) return p:getAccountID()==s.Account and p:getName()==s.Name end
local function active(s)
    for _,c in ipairs(QUEST_SYSTEM_NPC_INFO) do local r=s.Quests[c.QuestIdentification]; if r and (r.State==1 or r.State==3) then return r end end
end
busy = function(p)
    return p:getInterfaceUse()~=0 or p:getInterfaceType()~=0 or p:getState()==32 or p:getDieRegen()~=0 or p:getTeleport()~=0
end
function Q.Accrue(s,now)
    local delta=elapsed(now,s.LastTick); s.LastTick=now
    -- Backwards clock/reset (> half the tick range) never grants time.
    if delta>2147483647 then return end
    local r=active(s)
    if not r or r.State~=1 then s.Remainder=0; return end
    s.Remainder=(s.Remainder or 0)+delta
    local seconds=math.floor(s.Remainder/1000); s.Remainder=s.Remainder%1000
    local value=math.min(2147483647,r.OnlineSeconds+seconds)
    if value~=r.OnlineSeconds then r.OnlineSeconds=value; r.Dirty=true end
end
function Q.Flush(s)
    for _,r in pairs(s.Quests) do
        if r.State==1 and r.Dirty then
            if not Q.Store.Save(s,r) then return false end
            r.Dirty=false
        end
    end
    s.LastSave=tick()
    return true
end
local function retire(s)
    if not Q.Flush(s) then return false end
    if not C.ResumeOnLogin then
        local r=active(s)
        if r and r.State==1 then
            if not Q.Store.Transition(s,r,4) then return false end
            r.State=4
        end
    end
    return true
end
function Q.PlayerJoin(index)
    local p=User.new(index)
    local previous=sessions[index]
    if previous and same(p,previous) then return previous end
    if previous then
        if not retire(previous) then retired[#retired+1]=previous end
        sessions[index]=nil
    end
    local s={Index=index,Account=p:getAccountID(),Name=p:getName(),LastTick=tick(),LastSave=tick(),Quests={},Remainder=0}
    for i=#retired,1,-1 do
        local old=retired[i]
        if old.Account==s.Account and old.Name==s.Name then
            if not retire(old) then return nil end
            table.remove(retired,i)
        end
    end
    local rows=Q.Store.Load(s)
    if not rows then return nil end
    for _,c in ipairs(QUEST_SYSTEM_NPC_INFO) do s.Quests[c.QuestIdentification]=record(c.QuestIdentification) end
    for _,r in ipairs(rows) do
        if configs[r.QuestID] then
            if not C.ResumeOnLogin and r.State==1 then
                if not Q.Store.Transition(s,r,4) then return nil end
                r.State=4
            end
            s.Quests[r.QuestID]=r
        end
    end
    sessions[index]=s
    return s
end
function Q.PlayerLogout(index)
    local s=sessions[index]; if not s then return end
    if same(User.new(index),s) then Q.Accrue(s,tick()) end
    if not retire(s) then retired[#retired+1]=s end
    sessions[index]=nil
end
function Q.Timer()
    local now=tick()
    for index,s in pairs(sessions) do
        local p=User.new(index)
        if p:getConnected()<3 or not same(p,s) then
            -- No elapsed time is added after a missed disconnect/index reuse.
            if not retire(s) then retired[#retired+1]=s end
            sessions[index]=nil
        else
            Q.Accrue(s,now)
            if elapsed(now,s.LastSave)>=C.SaveInterval*1000 then Q.Flush(s) end
        end
    end
    for i=#retired,1,-1 do if retire(retired[i]) then table.remove(retired,i) end end
end
function Q.Inventory(p,id)
    local inv=Inventory.new(p:getIndex())
    local remaining,plan,counts={},{},{}
    for _,item in ipairs(QUEST_SYSTEM_NPC_REQUIREMENTS_ITEMS[id] or {}) do
        local count=0
        for slot=12,203 do
            if count>=item.Quantity then break end
            if inv:isItem(slot)~=0 and inv:getIndex(slot)==item.ItemIndex and
                (item.Level==-1 or inv:getLevel(slot)==item.Level) and
                (item.Skill==-1 or inv:getItemTable(slot,2)==item.Skill) and
                (item.Luck==-1 or inv:getItemTable(slot,3)==item.Luck) then
                local stack=GetStackItem(item.ItemIndex)>0
                local quantity=stack and math.max(1,inv:getDurability(slot)) or 1
                if remaining[slot]==nil then remaining[slot]=quantity end
                local take=math.min(item.Quantity-count,remaining[slot])
                remaining[slot]=remaining[slot]-take; count=count+take
                if take>0 then
                    plan[slot]=plan[slot] or {Quantity=quantity,Take=0,Stack=stack}
                    plan[slot].Take=plan[slot].Take+take
                end
            end
        end
        counts[#counts+1]=count
    end
    return counts,plan
end
function Q.Requirements(p,s,c)
    local r=s.Quests[c.QuestIdentification]
    local rows={}
    local balancesKnown=true
    local function add(label,current,required,time)
        if required>0 then rows[#rows+1]={Label=label,Current=math.min(current,2147483647),Required=required,Time=time} end
    end
    add('Tempo online desde o inicio',r.OnlineSeconds,c.OnlineSeconds,true)
    local stats={{'Nivel',p:getLevel(),c.Level},{'Resets',p:getReset(),c.Reset},{'Master resets',p:getMasterReset(),c.MReset},
        {'Zen',p:getMoney(),c.Zen},{'WCoin C',p:getCoin1(),c.Coin1},{'WCoin P',p:getCoin2(),c.Coin2},
        {'Goblin Point',p:getCoin3(),c.Coin3},{'VIP',p:getVip(),c.Vip},{'Jogadores derrotados',r.Kills,c.Kills}}
    for _,v in ipairs(stats) do add(v[1],v[2],v[3]) end
    for _,v in ipairs(currencyRequirements[c.QuestIdentification] or {}) do
        local balance=Q.Store.Balance(s,v.Currency)
        local label=currencies[v.Currency].Name
        if balance==nil then balancesKnown=false; label=label..' (indisponivel)' end
        add(label,balance or 0,v.Amount)
    end
    for i,v in ipairs(QUEST_SYSTEM_NPC_REQUIREMENTS_MONSTER[c.QuestIdentification] or {}) do
        add(v.Name or ('Monstro '..v.MonsterIndex),r['Kill'..i],v.Quantity)
    end
    local counts,plan=Q.Inventory(p,c.QuestIdentification)
    for i,v in ipairs(QUEST_SYSTEM_NPC_REQUIREMENTS_ITEMS[c.QuestIdentification] or {}) do
        add(v.Name or ('Item '..math.floor(v.ItemIndex/512)..'/'..(v.ItemIndex%512)..(v.Level>=0 and (' +'..v.Level) or '')),counts[i],v.Quantity)
    end
    if r.State==2 then for _,v in ipairs(rows) do v.Current=math.max(v.Current,v.Required) end end
    local ready=r.State==1 and balancesKnown
    for _,v in ipairs(rows) do if v.Current<v.Required then ready=false end end
    return rows,ready,plan
end
function Q.Start(p,s,id,run)
    local c=configs[id]; local r=s.Quests[id]
    if not c or not r or r.Run~=run or busy(p) then return 'Nao foi possivel iniciar agora.' end
    for _,old in pairs(s.Quests) do
        if old.State==2 then
            local pending=Q.Store.Pending(s,old.QuestID,old.Run)
            if not pending or #pending>0 then return 'Retire os premios pendentes antes de iniciar outra quest.' end
        end
    end
    if active(s) then return 'Conclua sua quest ativa antes de iniciar outra.' end
    if r.State==2 and not c.Repeatable then return 'Esta quest so pode ser concluida uma vez.' end
    local nextRun=Q.Store.Start(s,id,run,c.Repeatable)
    if not nextRun or nextRun.Run~=run+1 or nextRun.State~=1 then return 'Nao foi possivel registrar o inicio. Atualize a janela.' end
    s.Quests[id]=nextRun; s.LastTick=tick(); s.Remainder=0
    return 'Quest iniciada. Seu progresso comeca agora.'
end
function Q.Claim(p,s,id,run)
    local c=configs[id]; local r=s.Quests[id]
    if not c or not r or r.Run~=run or r.State~=1 or busy(p) then return 'Resgate indisponivel.' end
    Q.Accrue(s,tick())
    local rows,ready,plan=Q.Requirements(p,s,c)
    if not ready then return 'Conclua todos os requisitos antes de resgatar.' end
    for _,v in ipairs(QUEST_SYSTEM_NPC_REWARD_ITEMS[id] or {}) do
        if (v.Class==-1 or v.Class==p:getClass()) and InventoryCheckSpaceByItem(p:getIndex(),v.ItemIndex)~=1 then
            return 'Libere espaco no inventario antes de resgatar.'
        end
    end
    if not Q.Flush(s) then return 'Banco indisponivel. Tente novamente.' end
    -- Durable compare-and-set before any item/currency side effects.
    if not Q.Store.Transition(s,r,3) then return 'Resgate nao confirmado. Reabra a janela.' end
    r.State=3
    local ok,err=pcall(function()
        local inv=Inventory.new(p:getIndex())
        for slot,v in pairs(plan) do
            if v.Take==v.Quantity then InventoryDeleteItem(p:getIndex(),slot); SendInventoryDeleteItem(p:getIndex(),slot)
            else inv:setDurability(slot,v.Quantity-v.Take); inv:convertItem(slot) end
        end
        if next(plan) then ItemListSend(p:getIndex()) end
        if QUEST_SYSTEM_NPC_REMOVE_RESETS==1 and c.Reset>0 then
            local playerReset=p:getReset()-c.Reset
            p:setReset(playerReset); DataBase.SetDecreaseValue(TABLE_RESET,COLUMN_RESET[0],c.Reset,WHERE_RESET,p:getName())
        end
        if QUEST_SYSTEM_NPC_REMOVE_MRESETS==1 and c.MReset>0 then
            p:setMasterReset(p:getMasterReset()-c.MReset); DataBase.SetDecreaseValue(TABLE_MRESET,COLUMN_MRESET[0],c.MReset,WHERE_MRESET,p:getName())
        end
        local a=QUEST_SYSTEM_NPC_REMOVE_COIN1==1 and c.Coin1 or 0
        local b=QUEST_SYSTEM_NPC_REMOVE_COIN2==1 and c.Coin2 or 0
        local d=QUEST_SYSTEM_NPC_REMOVE_COIN3==1 and c.Coin3 or 0
        if a+b+d>0 then RemoveCoins(p:getIndex(),a,b,d) end
        local coins={0,0,0}
        for _,v in ipairs(QUEST_SYSTEM_NPC_REWARD_COINS[id] or {}) do
            if not v.Currency then coins[v.CoinIdentification]=coins[v.CoinIdentification]+v.CoinAmount end
        end
        if coins[1]+coins[2]+coins[3]>0 then AddCoins(p:getIndex(),unpack(coins)) end
        for _,v in ipairs(QUEST_SYSTEM_NPC_REWARD_BUFF[id] or {}) do AddEffect(p:getIndex(),1,v.EffectID,os.time()+v.EffectTime,0,0,0,0) end
        local items={}
        for _,v in ipairs(QUEST_SYSTEM_NPC_REWARD_ITEMS[id] or {}) do if v.Class==-1 or v.Class==p:getClass() then items[#items+1]=v end end
        if not Q.Store.Finish(s,r,items) then error('Finalizacao SQL nao confirmada') end
    end)
    if not ok then
        log('Resgate pendente para '..s.Name..', quest '..id..', tentativa '..run..': '..tostring(err))
        return 'Resgate pendente de conferencia. Avise a administracao.'
    end
    r.State=2
    return Q.Deliver(p,s,r)
end
function Q.MonsterDie(index,monsterIndex)
    local s=sessions[index]; if not s then return end
    local p=User.new(index); if not same(p,s) then return end
    local r=active(s); if not r or r.State~=1 then return end
    local monster=User.new(monsterIndex)
    for i,v in ipairs(QUEST_SYSTEM_NPC_REQUIREMENTS_MONSTER[r.QuestID] or {}) do
        if v.MonsterIndex==monster:getClass() then r['Kill'..i]=math.min(v.Quantity,r['Kill'..i]+1); r.Dirty=true end
    end
end
function Q.PlayerDie(index,target)
    local s=sessions[index]; if not s or index==target then return end
    if not same(User.new(index),s) then return end
    local r=active(s); if not r or r.State~=1 then return end
    r.Kills=math.min(configs[r.QuestID].Kills,r.Kills+1); r.Dirty=true
end
local function str(n,s) s=tostring(s or ''):sub(1,180); SetBytePacket(n,#s); SetCharPacketLength(n,s,#s) end
local function packet(p,request,kind,write)
    local n='QuestV2-'..p:getName(); CreatePacket(n,C.Packet); SetDwordPacket(n,request); SetBytePacket(n,kind)
    write(n); SendPacket(n,p:getIndex()); ClearPacket(n)
end
-- Availability uses every configured quest, independently of the selected tab.
function Q.Available(s)
    local unknown=false
    for _,c in ipairs(QUEST_SYSTEM_NPC_INFO) do
        local r=s.Quests[c.QuestIdentification]
        if r then
            if r.State==0 or r.State==1 or r.State==3 or r.State==4 then return true end
            if r.State==2 then
                if c.Repeatable then return true end
                local pending=Q.Store.Pending(s,r.QuestID,r.Run)
                if not pending then unknown=true
                elseif #pending>0 then return true end
            end
        end
    end
    if unknown then return nil end
    return false
end
local function availability(p,s,request)
    packet(p,request,7,function(n) SetBytePacket(n,Q.Available(s)==true and 1 or 0) end)
end
function Q.Status(p,s,id,request,catalog,message)
    if catalog then
        packet(p,request,1,function(n) SetBytePacket(n,#QUEST_SYSTEM_NPC_INFO) end)
        for _,c in ipairs(QUEST_SYSTEM_NPC_INFO) do
            packet(p,request,2,function(n) SetDwordPacket(n,c.QuestIdentification); str(n,c.QuestName); str(n,c.Description); SetBytePacket(n,c.Repeatable and 1 or 0) end)
        end
    end
    local c=configs[id]; local r=s.Quests[id]
    local rows,ready=Q.Requirements(p,s,c)
    local pending={}
    if r.State==2 then pending=Q.Store.Pending(s,id,r.Run) end
    packet(p,request,3,function(n)
        SetDwordPacket(n,id); SetDwordPacket(n,r.Run); SetBytePacket(n,r.State); SetBytePacket(n,ready and 1 or 0)
        SetDwordPacket(n,active(s) and active(s).QuestID or 0); SetBytePacket(n,#rows); SetBytePacket(n,pending and #pending or 255)
    end)
    for _,v in ipairs(rows) do packet(p,request,4,function(n) str(n,v.Label); SetDwordPacket(n,v.Current); SetDwordPacket(n,v.Required); SetBytePacket(n,v.Time and 1 or 0) end) end
    local rewardOrdinal=0
    for _,v in ipairs(QUEST_SYSTEM_NPC_REWARD_ITEMS[id] or {}) do
        if v.Class==-1 or v.Class==p:getClass() then
            rewardOrdinal=rewardOrdinal+1
            packet(p,request,5,function(n) str(n,v.Name); SetDwordPacket(n,v.Count); SetWordPacket(n,v.ItemIndex); SetBytePacket(n,v.Level) end)
            packet(p,request,8,function(n)
                SetWordPacket(n,rewardOrdinal)
                for _,key in ipairs({'Op1','Op2','Life','Exc','Ancient','JoH','SocketBonus','Sock1','Sock2','Sock3','Sock4','Sock5'}) do SetDwordPacket(n,v[key]) end
            end)
        end
    end
    for _,v in ipairs(QUEST_SYSTEM_NPC_REWARD_COINS[id] or {}) do packet(p,request,5,function(n) str(n,v.CoinName or (v.Currency and currencies[v.Currency].Name)); SetDwordPacket(n,v.CoinAmount); SetWordPacket(n,65535); SetBytePacket(n,0) end) end
    for _,v in ipairs(QUEST_SYSTEM_NPC_REWARD_BUFF[id] or {}) do packet(p,request,5,function(n) str(n,v.BuffName..' ('..v.EffectTime..'s)'); SetDwordPacket(n,1); SetWordPacket(n,65535); SetBytePacket(n,0) end) end
    availability(p,s,request)
    packet(p,request,6,function(n) str(n,message or '') end)
end
function Q.Protocol(index,number,name)
    if number~=C.Packet then return end
    local p=User.new(index)
    if name~='QuestV2Request-'..p:getName() then return end
    local action,request,id,run=GetBytePacket(name,-1),GetDwordPacket(name,-1),GetDwordPacket(name,-1),GetDwordPacket(name,-1)
    ClearPacket(name)
    if p:getConnected()<3 or not int(request) or request==0 or not int(id) or not int(run) or not int(action) or action<1 or action>6 then return true end
    if requestTimes[index] and elapsed(tick(),requestTimes[index])<500 then return true end
    requestTimes[index]=tick()
    local s=sessions[index]
    if not s or not same(p,s) then s=Q.PlayerJoin(index) end
    if not s then packet(p,request,6,function(n) str(n,'Banco indisponivel. Avise a administracao.') end); return true end
    if s.LastRequest and elapsed(tick(),s.LastRequest)<500 then return true end
    s.LastRequest=tick(); Q.Accrue(s,tick())
    if action==6 then availability(p,s,request); return true end
    if #QUEST_SYSTEM_NPC_INFO==0 then
        packet(p,request,1,function(n) SetBytePacket(n,0) end)
        availability(p,s,request)
        packet(p,request,6,function(n) str(n,'Nenhuma quest disponivel.') end)
        return true
    end
    if id==0 then id=active(s) and active(s).QuestID or QUEST_SYSTEM_NPC_INFO[1].QuestIdentification end
    if not configs[id] then return true end
    local message
    if action==2 then message=Q.Start(p,s,id,run)
    elseif action==3 then message=Q.Claim(p,s,id,run)
    elseif action==5 and s.Quests[id].Run==run and s.Quests[id].State==2 then message=Q.Deliver(p,s,s.Quests[id]) end
    Q.Status(p,s,id,request,action==1,message)
    return true
end
function Q.Init()
    if QUEST_SYSTEM_NPC_SWITCH~=1 then return end
    assert(C and type(C.ResumeOnLogin)=='boolean' and int(C.SaveInterval) and C.SaveInterval>=1,'Configure QuestWindowConfig')
    assert(#QUEST_SYSTEM_NPC_INFO<=32,'Configure no maximo 32 quests')
    local targets={}
    for key,v in pairs(currencies) do
        assert(type(key)=='string' and #key<=64 and key:match('^[A-Za-z_][A-Za-z0-9_]*$'),'ID de moeda invalido')
        assert(type(v.Name)=='string' and #v.Name>0 and #v.Name<=140,'Nome de moeda invalido')
        assert(v.Owner=='Account' or v.Owner=='Character','Owner deve ser Account ou Character')
        local target=(currencyTable(v)..'.'..identifier(v.Column)):lower()
        identifier(v.KeyColumn)
        assert(not targets[target],'Moedas duplicadas apontando para a mesma coluna SQL')
        targets[target]=true
    end
    for _,c in ipairs(QUEST_SYSTEM_NPC_INFO) do
        local id=c.QuestIdentification
        assert(int(id) and id>0 and not configs[id],'ID de quest invalido/duplicado')
        assert(type(c.Repeatable)=='boolean','Defina Repeatable=true/false em cada quest')
        c.OnlineSeconds=c.OnlineSeconds or 0
        for _,k in ipairs({'OnlineSeconds','Level','Reset','MReset','Zen','Coin1','Coin2','Coin3','Vip','Kills'}) do assert(int(c[k]),'Requisito invalido: '..k) end
        assert(#(QUEST_SYSTEM_NPC_REQUIREMENTS_ITEMS[id] or {})<=10 and #(QUEST_SYSTEM_NPC_REQUIREMENTS_MONSTER[id] or {})<=9,'Limite: 10 itens e 9 monstros')
        for _,v in ipairs(QUEST_SYSTEM_NPC_REQUIREMENTS_ITEMS[id] or {}) do
            assert(int(v.ItemIndex) and v.ItemIndex<=8191 and int(v.Quantity) and v.Quantity>0,'Item requerido invalido')
            for _,k in ipairs({'Level','Skill','Luck'}) do assert(v[k]==-1 or int(v[k]),'Filtro de item invalido') end
        end
        for _,v in ipairs(QUEST_SYSTEM_NPC_REQUIREMENTS_MONSTER[id] or {}) do
            assert(int(v.MonsterIndex) and int(v.Quantity) and v.Quantity>0,'Monstro requerido invalido')
        end
        local seen={}
        assert(#(currencyRequirements[id] or {})<=16,'Maximo de 16 requisitos de moeda')
        for _,v in ipairs(currencyRequirements[id] or {}) do
            assert(currencies[v.Currency] and not seen[v.Currency],'Moeda de requisito inexistente/duplicada')
            assert(int(v.Amount) and v.Amount>0 and type(v.Remove)=='boolean','Defina Amount positivo e Remove=true/false')
            seen[v.Currency]=true
        end
        local total=0
        for _,v in ipairs(QUEST_SYSTEM_NPC_REWARD_ITEMS[id] or {}) do
            for _,k in ipairs({'ItemIndex','Level','Op1','Op2','Life','Exc','Ancient','JoH','SocketBonus','Sock1','Sock2','Sock3','Sock4','Sock5','ItemTime','Count'}) do
                assert(int(v[k]),'Recompensa: campo invalido '..k)
            end
            assert(v.ItemIndex<=8191 and v.Level<=15 and v.Count>0 and (v.Class==-1 or (int(v.Class) and v.Class<=6)),'Recompensa invalida')
            total=total+v.Count
        end
        assert(total<=100,'Maximo de 100 itens de recompensa por tentativa')
        for _,v in ipairs(QUEST_SYSTEM_NPC_REWARD_COINS[id] or {}) do
            assert(int(v.CoinAmount),'Quantidade de moeda invalida')
            if v.Currency then
                assert(currencies[v.Currency] and v.CoinIdentification==nil,'Moeda de premio inexistente ou ambigua')
                assert(v.CoinName==nil or type(v.CoinName)=='string','Nome de premio invalido')
            else
                assert(int(v.CoinIdentification) and v.CoinIdentification>=1 and v.CoinIdentification<=3,'Moeda invalida')
            end
        end
        for _,op in ipairs(currencyOperations(id)) do assert(int(op.Credit),'Soma de premios em moeda excede o limite') end
        for _,v in ipairs(QUEST_SYSTEM_NPC_REWARD_BUFF[id] or {}) do assert(int(v.EffectID) and int(v.EffectTime),'Buff invalido') end
        configs[id]=c
    end
    GameServerFunctions.GameServerProtocol(Q.Protocol)
    GameServerFunctions.EnterCharacter(Q.PlayerJoin)
    GameServerFunctions.PlayerLogout(Q.PlayerLogout)
    GameServerFunctions.MonsterDie(Q.MonsterDie)
    GameServerFunctions.PlayerDie(Q.PlayerDie)
    Timer.Interval(1,Q.Timer)
    Timer.TimeOut(5,function() for i=OBJECT_START_USER,MAX_OBJECT do if User.new(i):getConnected()>=3 then Q.PlayerJoin(i) end end end)
end
Q.Init()
return Q
